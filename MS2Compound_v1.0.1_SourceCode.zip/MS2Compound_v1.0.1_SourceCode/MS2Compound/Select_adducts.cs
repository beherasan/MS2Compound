﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_delete
{
    public partial class Select_adducts : Form
    {
        public static string adduct_type_a = "";
        public static List<string> selected_adduct_items = new List<string>();
        public static string adduct_selected = "";
        //public static List<string> selected_item = new List<string>();
        public static List<string> int_items = new List<string>();
        public static string database_file_species = "";
        public static string query_file_species = ""; //ms-ms
        public static string input_query_file_ms = ""; //ms
        public static string output_dir_file_species = ""; //ms-ms
        public static string ms_output_dir_file_species = ""; //ms
        public static string mono_isotopic_mass_species = "";
        public static int active_tab_species = 0;
        public static string ionization_mode_adduct = "";
        public static string ion_mode_add = ""; // for storing the string ex: positive, negative
        
        //For MS
        public static string load_query_file_ms = "";

        public Select_adducts()
        {
            InitializeComponent();

        }

        
        private void Select_adducts_Load(object sender, EventArgs e)
        {
            if(Form1.adduct_type == 0)
            {
                string[] pos = { "M+H", "M+H-2H2O", "M+H-H2O", "M+NH4-H2O", "M+Li", "M+NH4", "M+Na", "M+CH3OH+H", "M+K", "M+ACN+H", "M+2Na-H", "M+IsoProp+H", "M+ACN+Na", "M+2K-H", "M+DMSO+H", "M+2ACN+H", "M+IsoProp+Na+H", "M+H+HCOONa", "2M+H", "2M+NH4", "2M+Na", "2M+2H+3H2O", "2M+K", "2M+ACN+H", "2M+ACN+Na", "2M+H-H2O", "M+2H", "M+H+NH4", "M+H+Na", "M+H+K", "M+ACN+2H", "M+2Na", "M+2ACN+2H", "M+3ACN+2H", "M+3H", "M+2H+Na", "M+H+2Na", "M+3Na", "M+H+2K" };
                for(int i=0; i<pos.Count(); i++)
                {
                    Select_adduct_box.Items.Add(pos[i]);
                }
                adduct_type_a = "Positive";
            }
            else if(Form1.adduct_type == 1)
            {
                string[] neg = { "M-H", "M-H20-H", "M+F", "M+Na-2H", "M+Cl", "M+K-2H", "M+FA-H", "M+Hac-H", "M+Br", "M+TFA-H", "M-H+HCOONa", "2M-H", "2M+FA-H", "2M+Hac-H", "3M-H", "M-2H", "M-3H" };
                for (int i = 0; i < neg.Count(); i++)
                {
                    Select_adduct_box.Items.Add(neg[i]);
                }
                adduct_type_a = "Negative";
            }
            else
            {
                Select_adduct_box.Items.Add("Unknown");
            }
        }
        private void Select_all_adducts_Click(object sender, EventArgs e)
        {
            int cnt = Select_adduct_box.Items.Count;
            for (int i = 0; i <= cnt - 1; i++)
            {
                if (Select_adduct_box.GetItemChecked(i) == false)
                {
                    Select_adduct_box.SetItemCheckState(i, CheckState.Checked);
                }
            }

        }

        private void submit_adducts_Click(object sender, EventArgs e)
        {
            selected_adduct_items.Clear();
            int cnt = Select_adduct_box.Items.Count;
            for (int i=0; i<cnt; i++)
            {
               if(Select_adduct_box.GetItemChecked(i)==true)
                {
                    selected_adduct_items.Add(Select_adduct_box.Items[i].ToString());
                }
            }
            //adduct_selected = Form1.adduct_selected;
            ionization_mode_adduct = Form1.ionization_mode;
            active_tab_species = Form1.active_tab;
            query_file_species = Form1.query_file;
            output_dir_file_species = Form1.output_dir_file;
            mono_isotopic_mass_species = Form1.mono_isotopic_mass;
            database_file_species = Form1.database_file;
            input_query_file_ms = Form1.query_file_ms;
            ms_output_dir_file_species = Form1.ms_output_dir_file;

            //For MS
            load_query_file_ms = Form1.ms_set_ip_file;
            Form fm1 = new Form1();
            fm1.Show();
            this.Hide();
            /* Add the tab changers to focus on the tab*/
            /* positve or negative has to be view in the form1*/
        }

        private void Select_adducts_FormClosing(object sender, FormClosingEventArgs e)
        {
            selected_adduct_items.Clear();
            int cnt = Select_adduct_box.Items.Count;
            for (int i = 0; i < cnt; i++)
            {
                if (Select_adduct_box.GetItemChecked(i) == true)
                {
                    selected_adduct_items.Add(Select_adduct_box.Items[i].ToString());
                }
            }
            //adduct_selected = Form1.adduct_selected;
            ionization_mode_adduct = Form1.ionization_mode;
            active_tab_species = Form1.active_tab;
            Form fm1 = new Form1();
            fm1.Show();
            this.Hide();
        }

        private void Close_adducts_Click(object sender, EventArgs e)
        {
            selected_adduct_items.Clear();
            int cnt = Select_adduct_box.Items.Count;
            for (int i = 0; i < cnt; i++)
            {
                if (Select_adduct_box.GetItemChecked(i) == true)
                {
                    selected_adduct_items.Add(Select_adduct_box.Items[i].ToString());
                }
            }
            //adduct_selected = Form1.adduct_selected;
            ionization_mode_adduct = Form1.ionization_mode;
            active_tab_species = Form1.active_tab;
            Form fm1 = new Form1();
            fm1.Show();
            this.Hide();
        }

        private void adducts_clear_all_Click(object sender, EventArgs e)
        {
            int cnt = Select_adduct_box.Items.Count;
            for (int i = 0; i <= cnt - 1; i++)
            {
                if (Select_adduct_box.GetItemChecked(i) == true)
                {
                    Select_adduct_box.SetItemCheckState(i, CheckState.Unchecked);
                }
            }
        }
    }
}
