﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;
using System.IO;


namespace Test_delete
{
    public partial class Select_species : Form
    {
        public static List<string> selected_item = new List<string>();
        public static List<string> selected_items = new List<string>();
        public static List<string> int_items = new List<string>();
        public static string database_file_species = "";
        public static string query_file_species = "";
        public static string ms_query_file_species = "";
        public static string output_dir_file_species = ""; //for ms-ms 
        public static string ms_output_dir_file_species = ""; //for ms
        public static string mono_isotopic_mass_species = "";
        public static int active_tab_species = 0;
        public static string ms_compound_fldr = "";
        public Select_species()
        {
             
             InitializeComponent();
            
            var myDict = new Dictionary<string, List<string>>();
            string[] lines = System.IO.File.ReadAllLines(System.IO.Directory.GetCurrentDirectory() + "\\" + "Database\\" + "SpeciesList.txt");

            foreach (string line in lines)
            {
                if (!myDict.ContainsKey(line[1].ToString()))
                {
                    myDict[line[1].ToString()] = new List<string> { line[0].ToString() + '_' + line[2].ToString() };
                }
                else
                {
                    myDict[line[1].ToString()].Add(line[0].ToString() + '_' + line[2].ToString());
                }

            }

        }
        
        private void Select_species_Load(object sender, EventArgs e)
        {
            Dictionary<string, string> dict = new Dictionary<string, string>();
            string get_file = "Database\\" + "SpeciesList.txt";
            using (System.IO.TextReader tr1 = System.IO.File.OpenText(System.IO.Directory.GetCurrentDirectory() + "\\" + get_file))
            {
                string line1 = "";
                while ((line1 = tr1.ReadLine()) != null)
                {
                    string[] items1 = line1.Split('\t');
                    if (!dict.ContainsKey(items1[1]))
                    {
                        dict.Add(items1[1], items1[0] + "_" + items1[2]);
                    }
                    else
                    {
                        dict[items1[1]] = dict[items1[1]] + ";" + items1[0] + "_" + items1[2];
                    }
                }
            }

            /*foreach (KeyValuePair<string, string> keypair in dict)
            {
                textBox1.Text = textBox1.Text + keypair.Value + Environment.NewLine;
            } */
            int cnt_root = 0;
            foreach (KeyValuePair<string, string> keypair in dict)
            {
                int cnt_sub = 0;
                treeView1.Nodes.Add(keypair.Key);
                string[] splitstr = keypair.Value.Split(';');
                for (int i = 0; i < splitstr.Length; i++)
                {
                    /* textBox1.Text = textBox1.Text + i.ToString() + splitstr[i] + Environment.NewLine; */
                    //MessageBox.Show(splitstr[i].ToString());
                    treeView1.Nodes[cnt_root].Nodes.Add(splitstr[i]);
                }
                cnt_sub += 1;

                cnt_root += 1;
            }
        }

        private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
        {
            
            treeView1.BeginUpdate();
            foreach (TreeNode tn in e.Node.Nodes)
            {
                tn.Checked = e.Node.Checked;
            }
            treeView1.EndUpdate();
        }

        public Process ProcessRunner(string cmd)
        {
            System.Diagnostics.Process prcs = new System.Diagnostics.Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = cmd;
            //sra_file_browse.Text = startInfo.Arguments;
            prcs.StartInfo = startInfo;
            prcs.Start();
            prcs.WaitForExit();
            return prcs;
        }

        private void treeView1_Click(object sender, EventArgs e)
        {

            //List<string> selected_item = new List<string>();
            textBox2.Text = "";
            List<string> nd = new List<string>();
            foreach (TreeNode node_parent in treeView1.Nodes)
            {
                foreach (TreeNode child_node in treeView1.Nodes[node_parent.Index].Nodes)
                {
                    if (child_node.Checked == true)
                    {
                        nd.Add(node_parent.Index.ToString() + "@" + child_node.ToString() + "@" + node_parent.ToString());
                        if(!int_items.Contains(node_parent.ToString()))
                            {
                            
                            int_items.Add(node_parent.ToString());
                            }
                    }
                    

                }

            }
            selected_item.Clear();
            for (int nd_iter = 0; nd_iter < nd.Count; nd_iter++)
            {
                //MessageBox.Show(nd[nd_iter].ToString());
                string[] split_item = nd[nd_iter].Split('@');
                textBox2.Text = textBox2.Text + split_item[2].Replace("TreeNode: ", "") + split_item[1].Replace("TreeNode", "") + Environment.NewLine;
                selected_item.Add(nd[nd_iter]);
                //MessageBox.Show(split_item[2].Replace("TreeNode: ", "") + split_item[1].Replace("TreeNode", ""));
                //MessageBox.Show(nd[nd_iter]);
            }
            
            /*
            string[] split_param = textBox2.Text.Split('\n');
            for (int i =0; i < split_param.Length; i++)
            {
                if(split_param[i].Length > 1)
                {
                    
                    selected_item.Add(split_param[i]);
                    //selected_item_only_id.Add(split_param[i].Split('_')[0]);
                }
                
            } */

            /*for (int asp = 0; asp < selected_item.Count; asp++)
            {
                MessageBox.Show(selected_item[asp]);
            }*/
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int cnt_sel_items = selected_item.Count;
            for (int i = 0; i < cnt_sel_items; i++)
            {
                selected_items.Add(selected_item[i]);
            }
            active_tab_species = Form1.active_tab;
            database_file_species = Form1.database_file;
            query_file_species = Form1.query_file;
            output_dir_file_species = Form1.output_dir_file;
            mono_isotopic_mass_species = Form1.mono_isotopic_mass;
            ms_query_file_species = Form1.query_file_ms;
            ms_output_dir_file_species = Form1.ms_output_dir_file;
            //ms_output_dir_file_species = Form1.ms_output_dir_file;
            Form1 fm1 = new Form1();
            fm1.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int cnt_sel_items = selected_item.Count;
            for (int i = 0; i <cnt_sel_items; i++)
            {
                selected_items.Add(selected_item[i]);
            }
            active_tab_species = Form1.active_tab;
            database_file_species = Form1.database_file;
            query_file_species = Form1.query_file;
            output_dir_file_species = Form1.output_dir_file;
            mono_isotopic_mass_species = Form1.mono_isotopic_mass;
            ms_query_file_species = Form1.query_file_ms;
            ms_output_dir_file_species = Form1.ms_output_dir_file;
            ms_compound_fldr = Form1.ms_compound_fldr;
            Form1 fm1 = new Form1();
            fm1.Show();
            this.Hide();
        }

        private void Select_species_FormClosing(object sender, FormClosingEventArgs e)
        {
            active_tab_species = Form1.active_tab;
            Form1 fm1 = new Form1();
            fm1.Show();
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void treeView1_BeforeCheck(object sender, TreeViewCancelEventArgs e)
        {
            
        }
    }
}
