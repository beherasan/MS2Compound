﻿namespace Test_delete
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Create_Custom_DB_upload = new System.Windows.Forms.Button();
            this.Create_Custom_DB_upload_path = new System.Windows.Forms.TextBox();
            this.Create_Custom_DB_set_op_dir_label = new System.Windows.Forms.Label();
            this.Create_Custom_DB_upload_label = new System.Windows.Forms.Label();
            this.Create_Custom_DB_set_op_dir = new System.Windows.Forms.TextBox();
            this.Create_Custom_DB_browse_op_dir = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Create_Custom_DB_fragment_check = new System.Windows.Forms.CheckBox();
            this.Create_Custom_DB_list_of_fragments = new System.Windows.Forms.ComboBox();
            this.Create_Custom_DB_set_spectra_type = new System.Windows.Forms.ComboBox();
            this.Create_Custom_DB_spectra_type_label = new System.Windows.Forms.Label();
            this.Create_Custom_DB_calc_monoisotopicmass = new System.Windows.Forms.CheckBox();
            this.Create_Custom_DB_submit = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ms_ionization_mode = new System.Windows.Forms.GroupBox();
            this.ms_adduct_count = new System.Windows.Forms.Label();
            this.ms_negative_click = new System.Windows.Forms.Button();
            this.ms_positive_click = new System.Windows.Forms.Button();
            this.ms_lbl_molecular_weight_tolerance = new System.Windows.Forms.Label();
            this.ms_mol_weight_tolerance = new System.Windows.Forms.TextBox();
            this.ms_select_unit = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ms_select_species_lbl = new System.Windows.Forms.Label();
            this.ms_set_output_dir = new System.Windows.Forms.TextBox();
            this.ms_label_or = new System.Windows.Forms.Label();
            this.ms_browse_input_file = new System.Windows.Forms.Button();
            this.ms_browse_op_dir = new System.Windows.Forms.Button();
            this.ms_set_input_file = new System.Windows.Forms.TextBox();
            this.ms_select_species = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.ms_browse = new System.Windows.Forms.Button();
            this.browse_species = new System.Windows.Forms.TextBox();
            this.ms_reset = new System.Windows.Forms.Button();
            this.ms_search = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.msms_reset = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.msms_cid_energy = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Fragment_mass_tol = new System.Windows.Forms.TextBox();
            this.Parent_ion_mass_tol = new System.Windows.Forms.TextBox();
            this.Fragment_da = new System.Windows.Forms.ComboBox();
            this.Parent_da = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.msms_min_number_frags = new System.Windows.Forms.ComboBox();
            this.msms_min_number_of_fragments = new System.Windows.Forms.Label();
            this.ms_ms_ionization = new System.Windows.Forms.GroupBox();
            this.adduct_items_count = new System.Windows.Forms.Label();
            this.msms_neg_adduct = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.CID_energy = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ms_ms_load_monoisotopic_mass_label = new System.Windows.Forms.Label();
            this.ms_ms_load_output_file_label = new System.Windows.Forms.Label();
            this.Load_query_file_label = new System.Windows.Forms.Label();
            this.ms_ms_species_count = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.Browse_monoisotopic_mass = new System.Windows.Forms.Button();
            this.Load_monoisotopic_mass = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Browse_output_dir = new System.Windows.Forms.Button();
            this.Output_dir = new System.Windows.Forms.TextBox();
            this.Browse_database_dir = new System.Windows.Forms.Button();
            this.Load_database = new System.Windows.Forms.TextBox();
            this.Browse_query_file = new System.Windows.Forms.Button();
            this.Load_query_file = new System.Windows.Forms.TextBox();
            this.MS2_search = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Browse_query_file_dialog = new System.Windows.Forms.OpenFileDialog();
            this.Browse_dir_dialog = new System.Windows.Forms.FolderBrowserDialog();
            this.Load_mono_file = new System.Windows.Forms.OpenFileDialog();
            this.ms_load_input_file_dialog = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Create_Custom_DB_browse_file = new System.Windows.Forms.OpenFileDialog();
            this.Create_Custom_DB_browse_op_path = new System.Windows.Forms.FolderBrowserDialog();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.ms_ionization_mode.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.ms_ms_ionization.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(9, 79);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(568, 513);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Controls.Add(this.groupBox6);
            this.tabPage5.Controls.Add(this.Create_Custom_DB_calc_monoisotopicmass);
            this.tabPage5.Controls.Add(this.Create_Custom_DB_submit);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(560, 487);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Create Custom Database";
            this.tabPage5.UseVisualStyleBackColor = true;
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox7.Controls.Add(this.Create_Custom_DB_upload);
            this.groupBox7.Controls.Add(this.Create_Custom_DB_upload_path);
            this.groupBox7.Controls.Add(this.Create_Custom_DB_set_op_dir_label);
            this.groupBox7.Controls.Add(this.Create_Custom_DB_upload_label);
            this.groupBox7.Controls.Add(this.Create_Custom_DB_set_op_dir);
            this.groupBox7.Controls.Add(this.Create_Custom_DB_browse_op_dir);
            this.groupBox7.Location = new System.Drawing.Point(7, 22);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(550, 127);
            this.groupBox7.TabIndex = 15;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Select files";
            // 
            // Create_Custom_DB_upload
            // 
            this.Create_Custom_DB_upload.Location = new System.Drawing.Point(463, 19);
            this.Create_Custom_DB_upload.Name = "Create_Custom_DB_upload";
            this.Create_Custom_DB_upload.Size = new System.Drawing.Size(75, 35);
            this.Create_Custom_DB_upload.TabIndex = 0;
            this.Create_Custom_DB_upload.Text = "Upload";
            this.Create_Custom_DB_upload.UseVisualStyleBackColor = true;
            this.Create_Custom_DB_upload.Click += new System.EventHandler(this.Create_Custom_DB_upload_Click);
            // 
            // Create_Custom_DB_upload_path
            // 
            this.Create_Custom_DB_upload_path.Location = new System.Drawing.Point(114, 19);
            this.Create_Custom_DB_upload_path.Multiline = true;
            this.Create_Custom_DB_upload_path.Name = "Create_Custom_DB_upload_path";
            this.Create_Custom_DB_upload_path.Size = new System.Drawing.Size(326, 35);
            this.Create_Custom_DB_upload_path.TabIndex = 1;
            // 
            // Create_Custom_DB_set_op_dir_label
            // 
            this.Create_Custom_DB_set_op_dir_label.AutoSize = true;
            this.Create_Custom_DB_set_op_dir_label.Location = new System.Drawing.Point(9, 83);
            this.Create_Custom_DB_set_op_dir_label.Name = "Create_Custom_DB_set_op_dir_label";
            this.Create_Custom_DB_set_op_dir_label.Size = new System.Drawing.Size(99, 13);
            this.Create_Custom_DB_set_op_dir_label.TabIndex = 13;
            this.Create_Custom_DB_set_op_dir_label.Text = "Set output directory";
            // 
            // Create_Custom_DB_upload_label
            // 
            this.Create_Custom_DB_upload_label.AutoSize = true;
            this.Create_Custom_DB_upload_label.Location = new System.Drawing.Point(9, 27);
            this.Create_Custom_DB_upload_label.Name = "Create_Custom_DB_upload_label";
            this.Create_Custom_DB_upload_label.Size = new System.Drawing.Size(84, 13);
            this.Create_Custom_DB_upload_label.TabIndex = 2;
            this.Create_Custom_DB_upload_label.Text = "Upload Input file";
            this.Create_Custom_DB_upload_label.Click += new System.EventHandler(this.label2_Click);
            // 
            // Create_Custom_DB_set_op_dir
            // 
            this.Create_Custom_DB_set_op_dir.Location = new System.Drawing.Point(114, 75);
            this.Create_Custom_DB_set_op_dir.Multiline = true;
            this.Create_Custom_DB_set_op_dir.Name = "Create_Custom_DB_set_op_dir";
            this.Create_Custom_DB_set_op_dir.Size = new System.Drawing.Size(326, 35);
            this.Create_Custom_DB_set_op_dir.TabIndex = 12;
            // 
            // Create_Custom_DB_browse_op_dir
            // 
            this.Create_Custom_DB_browse_op_dir.Location = new System.Drawing.Point(463, 75);
            this.Create_Custom_DB_browse_op_dir.Name = "Create_Custom_DB_browse_op_dir";
            this.Create_Custom_DB_browse_op_dir.Size = new System.Drawing.Size(75, 35);
            this.Create_Custom_DB_browse_op_dir.TabIndex = 11;
            this.Create_Custom_DB_browse_op_dir.Text = "Browse";
            this.Create_Custom_DB_browse_op_dir.UseVisualStyleBackColor = true;
            this.Create_Custom_DB_browse_op_dir.Click += new System.EventHandler(this.Create_Custom_DB_browse_op_dir_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(24, 404);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(516, 26);
            this.label5.TabIndex = 10;
            this.label5.Text = resources.GetString("label5.Text");
            this.label5.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox6.Controls.Add(this.label2);
            this.groupBox6.Controls.Add(this.Create_Custom_DB_fragment_check);
            this.groupBox6.Controls.Add(this.Create_Custom_DB_list_of_fragments);
            this.groupBox6.Controls.Add(this.Create_Custom_DB_set_spectra_type);
            this.groupBox6.Controls.Add(this.Create_Custom_DB_spectra_type_label);
            this.groupBox6.Location = new System.Drawing.Point(7, 181);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(550, 112);
            this.groupBox6.TabIndex = 9;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Fragment spectra prediction";
            this.groupBox6.Enter += new System.EventHandler(this.groupBox6_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Ion mode";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // Create_Custom_DB_fragment_check
            // 
            this.Create_Custom_DB_fragment_check.AutoSize = true;
            this.Create_Custom_DB_fragment_check.Location = new System.Drawing.Point(24, 31);
            this.Create_Custom_DB_fragment_check.Name = "Create_Custom_DB_fragment_check";
            this.Create_Custom_DB_fragment_check.Size = new System.Drawing.Size(110, 17);
            this.Create_Custom_DB_fragment_check.TabIndex = 3;
            this.Create_Custom_DB_fragment_check.Text = "Fragment MS/MS";
            this.Create_Custom_DB_fragment_check.UseVisualStyleBackColor = true;
            this.Create_Custom_DB_fragment_check.CheckedChanged += new System.EventHandler(this.Create_Custom_DB_fragment_check_CheckedChanged);
            // 
            // Create_Custom_DB_list_of_fragments
            // 
            this.Create_Custom_DB_list_of_fragments.AutoCompleteCustomSource.AddRange(new string[] {
            "Positive",
            "Negative"});
            this.Create_Custom_DB_list_of_fragments.FormattingEnabled = true;
            this.Create_Custom_DB_list_of_fragments.Items.AddRange(new object[] {
            "Positive",
            "Negative"});
            this.Create_Custom_DB_list_of_fragments.Location = new System.Drawing.Point(143, 58);
            this.Create_Custom_DB_list_of_fragments.Name = "Create_Custom_DB_list_of_fragments";
            this.Create_Custom_DB_list_of_fragments.Size = new System.Drawing.Size(121, 21);
            this.Create_Custom_DB_list_of_fragments.TabIndex = 4;
            this.Create_Custom_DB_list_of_fragments.SelectedIndexChanged += new System.EventHandler(this.Create_Custom_DB_list_of_fragments_SelectedIndexChanged);
            // 
            // Create_Custom_DB_set_spectra_type
            // 
            this.Create_Custom_DB_set_spectra_type.FormattingEnabled = true;
            this.Create_Custom_DB_set_spectra_type.Location = new System.Drawing.Point(399, 58);
            this.Create_Custom_DB_set_spectra_type.Name = "Create_Custom_DB_set_spectra_type";
            this.Create_Custom_DB_set_spectra_type.Size = new System.Drawing.Size(121, 21);
            this.Create_Custom_DB_set_spectra_type.TabIndex = 7;
            // 
            // Create_Custom_DB_spectra_type_label
            // 
            this.Create_Custom_DB_spectra_type_label.AutoSize = true;
            this.Create_Custom_DB_spectra_type_label.Location = new System.Drawing.Point(297, 61);
            this.Create_Custom_DB_spectra_type_label.Name = "Create_Custom_DB_spectra_type_label";
            this.Create_Custom_DB_spectra_type_label.Size = new System.Drawing.Size(67, 13);
            this.Create_Custom_DB_spectra_type_label.TabIndex = 6;
            this.Create_Custom_DB_spectra_type_label.Text = "Spectra type";
            this.Create_Custom_DB_spectra_type_label.Click += new System.EventHandler(this.Create_Custom_DB_spectra_type_label_Click);
            // 
            // Create_Custom_DB_calc_monoisotopicmass
            // 
            this.Create_Custom_DB_calc_monoisotopicmass.AutoSize = true;
            this.Create_Custom_DB_calc_monoisotopicmass.Location = new System.Drawing.Point(31, 314);
            this.Create_Custom_DB_calc_monoisotopicmass.Name = "Create_Custom_DB_calc_monoisotopicmass";
            this.Create_Custom_DB_calc_monoisotopicmass.Size = new System.Drawing.Size(162, 17);
            this.Create_Custom_DB_calc_monoisotopicmass.TabIndex = 8;
            this.Create_Custom_DB_calc_monoisotopicmass.Text = "Calculate monoisotopic mass";
            this.Create_Custom_DB_calc_monoisotopicmass.UseVisualStyleBackColor = true;
            // 
            // Create_Custom_DB_submit
            // 
            this.Create_Custom_DB_submit.Location = new System.Drawing.Point(406, 337);
            this.Create_Custom_DB_submit.Name = "Create_Custom_DB_submit";
            this.Create_Custom_DB_submit.Size = new System.Drawing.Size(141, 37);
            this.Create_Custom_DB_submit.TabIndex = 5;
            this.Create_Custom_DB_submit.Text = "Submit";
            this.Create_Custom_DB_submit.UseVisualStyleBackColor = true;
            this.Create_Custom_DB_submit.Click += new System.EventHandler(this.Create_Custom_DB_submit_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.ms_reset);
            this.tabPage1.Controls.Add(this.ms_search);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(560, 487);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "MS search";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox3.Controls.Add(this.ms_ionization_mode);
            this.groupBox3.Controls.Add(this.ms_lbl_molecular_weight_tolerance);
            this.groupBox3.Controls.Add(this.ms_mol_weight_tolerance);
            this.groupBox3.Controls.Add(this.ms_select_unit);
            this.groupBox3.Location = new System.Drawing.Point(6, 298);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(543, 99);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Parameters";
            // 
            // ms_ionization_mode
            // 
            this.ms_ionization_mode.Controls.Add(this.ms_adduct_count);
            this.ms_ionization_mode.Controls.Add(this.ms_negative_click);
            this.ms_ionization_mode.Controls.Add(this.ms_positive_click);
            this.ms_ionization_mode.Location = new System.Drawing.Point(13, 21);
            this.ms_ionization_mode.Margin = new System.Windows.Forms.Padding(2);
            this.ms_ionization_mode.Name = "ms_ionization_mode";
            this.ms_ionization_mode.Padding = new System.Windows.Forms.Padding(2);
            this.ms_ionization_mode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ms_ionization_mode.Size = new System.Drawing.Size(225, 65);
            this.ms_ionization_mode.TabIndex = 21;
            this.ms_ionization_mode.TabStop = false;
            this.ms_ionization_mode.Text = "Ionization mode";
            // 
            // ms_adduct_count
            // 
            this.ms_adduct_count.AutoSize = true;
            this.ms_adduct_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ms_adduct_count.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ms_adduct_count.Location = new System.Drawing.Point(28, 46);
            this.ms_adduct_count.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ms_adduct_count.Name = "ms_adduct_count";
            this.ms_adduct_count.Size = new System.Drawing.Size(25, 13);
            this.ms_adduct_count.TabIndex = 20;
            this.ms_adduct_count.Text = "aaa";
            this.ms_adduct_count.Click += new System.EventHandler(this.ms_adduct_count_Click);
            // 
            // ms_negative_click
            // 
            this.ms_negative_click.Location = new System.Drawing.Point(142, 16);
            this.ms_negative_click.Margin = new System.Windows.Forms.Padding(2);
            this.ms_negative_click.Name = "ms_negative_click";
            this.ms_negative_click.Size = new System.Drawing.Size(62, 26);
            this.ms_negative_click.TabIndex = 1;
            this.ms_negative_click.Text = "Negative";
            this.ms_negative_click.UseVisualStyleBackColor = true;
            this.ms_negative_click.Click += new System.EventHandler(this.ms_negative_click_Click);
            // 
            // ms_positive_click
            // 
            this.ms_positive_click.Location = new System.Drawing.Point(16, 17);
            this.ms_positive_click.Margin = new System.Windows.Forms.Padding(2);
            this.ms_positive_click.Name = "ms_positive_click";
            this.ms_positive_click.Size = new System.Drawing.Size(56, 26);
            this.ms_positive_click.TabIndex = 0;
            this.ms_positive_click.Text = "Positive";
            this.ms_positive_click.UseVisualStyleBackColor = true;
            this.ms_positive_click.Click += new System.EventHandler(this.ms_positive_click_Click);
            // 
            // ms_lbl_molecular_weight_tolerance
            // 
            this.ms_lbl_molecular_weight_tolerance.AutoSize = true;
            this.ms_lbl_molecular_weight_tolerance.Location = new System.Drawing.Point(255, 47);
            this.ms_lbl_molecular_weight_tolerance.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ms_lbl_molecular_weight_tolerance.Name = "ms_lbl_molecular_weight_tolerance";
            this.ms_lbl_molecular_weight_tolerance.Size = new System.Drawing.Size(126, 13);
            this.ms_lbl_molecular_weight_tolerance.TabIndex = 2;
            this.ms_lbl_molecular_weight_tolerance.Text = "Precursor mass tolerance";
            // 
            // ms_mol_weight_tolerance
            // 
            this.ms_mol_weight_tolerance.Location = new System.Drawing.Point(398, 45);
            this.ms_mol_weight_tolerance.Margin = new System.Windows.Forms.Padding(2);
            this.ms_mol_weight_tolerance.Name = "ms_mol_weight_tolerance";
            this.ms_mol_weight_tolerance.Size = new System.Drawing.Size(53, 20);
            this.ms_mol_weight_tolerance.TabIndex = 1;
            this.ms_mol_weight_tolerance.Text = "0.05";
            this.ms_mol_weight_tolerance.TextChanged += new System.EventHandler(this.textBox4_TextChanged_2);
            // 
            // ms_select_unit
            // 
            this.ms_select_unit.FormattingEnabled = true;
            this.ms_select_unit.Items.AddRange(new object[] {
            "Da",
            "ppm"});
            this.ms_select_unit.Location = new System.Drawing.Point(466, 45);
            this.ms_select_unit.Margin = new System.Windows.Forms.Padding(2);
            this.ms_select_unit.Name = "ms_select_unit";
            this.ms_select_unit.Size = new System.Drawing.Size(55, 21);
            this.ms_select_unit.TabIndex = 3;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox4.Controls.Add(this.ms_select_species_lbl);
            this.groupBox4.Controls.Add(this.ms_set_output_dir);
            this.groupBox4.Controls.Add(this.ms_label_or);
            this.groupBox4.Controls.Add(this.ms_browse_input_file);
            this.groupBox4.Controls.Add(this.ms_browse_op_dir);
            this.groupBox4.Controls.Add(this.ms_set_input_file);
            this.groupBox4.Controls.Add(this.ms_select_species);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.ms_browse);
            this.groupBox4.Controls.Add(this.browse_species);
            this.groupBox4.Location = new System.Drawing.Point(6, 23);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(543, 248);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Select files";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // ms_select_species_lbl
            // 
            this.ms_select_species_lbl.AutoSize = true;
            this.ms_select_species_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ms_select_species_lbl.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ms_select_species_lbl.Location = new System.Drawing.Point(10, 146);
            this.ms_select_species_lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ms_select_species_lbl.Name = "ms_select_species_lbl";
            this.ms_select_species_lbl.Size = new System.Drawing.Size(31, 13);
            this.ms_select_species_lbl.TabIndex = 19;
            this.ms_select_species_lbl.Text = "bbbb";
            this.ms_select_species_lbl.Click += new System.EventHandler(this.ms_select_species_lbl_Click);
            // 
            // ms_set_output_dir
            // 
            this.ms_set_output_dir.Location = new System.Drawing.Point(11, 174);
            this.ms_set_output_dir.Margin = new System.Windows.Forms.Padding(2);
            this.ms_set_output_dir.Multiline = true;
            this.ms_set_output_dir.Name = "ms_set_output_dir";
            this.ms_set_output_dir.Size = new System.Drawing.Size(467, 51);
            this.ms_set_output_dir.TabIndex = 4;
            this.ms_set_output_dir.Text = "Set output directory";
            // 
            // ms_label_or
            // 
            this.ms_label_or.AutoSize = true;
            this.ms_label_or.Location = new System.Drawing.Point(3, 42);
            this.ms_label_or.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ms_label_or.Name = "ms_label_or";
            this.ms_label_or.Size = new System.Drawing.Size(73, 13);
            this.ms_label_or.TabIndex = 6;
            this.ms_label_or.Text = "Load input file";
            // 
            // ms_browse_input_file
            // 
            this.ms_browse_input_file.Location = new System.Drawing.Point(484, 35);
            this.ms_browse_input_file.Margin = new System.Windows.Forms.Padding(2);
            this.ms_browse_input_file.Name = "ms_browse_input_file";
            this.ms_browse_input_file.Size = new System.Drawing.Size(56, 30);
            this.ms_browse_input_file.TabIndex = 5;
            this.ms_browse_input_file.Text = "Browse";
            this.ms_browse_input_file.UseVisualStyleBackColor = true;
            this.ms_browse_input_file.Click += new System.EventHandler(this.ms_browse_input_file_Click_1);
            // 
            // ms_browse_op_dir
            // 
            this.ms_browse_op_dir.Location = new System.Drawing.Point(482, 183);
            this.ms_browse_op_dir.Margin = new System.Windows.Forms.Padding(2);
            this.ms_browse_op_dir.Name = "ms_browse_op_dir";
            this.ms_browse_op_dir.Size = new System.Drawing.Size(53, 32);
            this.ms_browse_op_dir.TabIndex = 18;
            this.ms_browse_op_dir.Text = "Browse";
            this.ms_browse_op_dir.UseVisualStyleBackColor = true;
            this.ms_browse_op_dir.Click += new System.EventHandler(this.ms_browse_op_dir_Click);
            // 
            // ms_set_input_file
            // 
            this.ms_set_input_file.Location = new System.Drawing.Point(80, 35);
            this.ms_set_input_file.Margin = new System.Windows.Forms.Padding(2);
            this.ms_set_input_file.Multiline = true;
            this.ms_set_input_file.Name = "ms_set_input_file";
            this.ms_set_input_file.Size = new System.Drawing.Size(401, 30);
            this.ms_set_input_file.TabIndex = 4;
            this.ms_set_input_file.Text = "Load input file";
            // 
            // ms_select_species
            // 
            this.ms_select_species.Location = new System.Drawing.Point(9, 84);
            this.ms_select_species.Margin = new System.Windows.Forms.Padding(2);
            this.ms_select_species.Name = "ms_select_species";
            this.ms_select_species.Size = new System.Drawing.Size(130, 47);
            this.ms_select_species.TabIndex = 16;
            this.ms_select_species.Text = "Select species";
            this.ms_select_species.UseVisualStyleBackColor = true;
            this.ms_select_species.Click += new System.EventHandler(this.ms_select_species_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(143, 101);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "OR";
            // 
            // ms_browse
            // 
            this.ms_browse.Location = new System.Drawing.Point(480, 96);
            this.ms_browse.Margin = new System.Windows.Forms.Padding(2);
            this.ms_browse.Name = "ms_browse";
            this.ms_browse.Size = new System.Drawing.Size(56, 27);
            this.ms_browse.TabIndex = 14;
            this.ms_browse.Text = "Browse";
            this.ms_browse.UseVisualStyleBackColor = true;
            this.ms_browse.Click += new System.EventHandler(this.ms_browse_Click);
            // 
            // browse_species
            // 
            this.browse_species.Location = new System.Drawing.Point(170, 88);
            this.browse_species.Margin = new System.Windows.Forms.Padding(2);
            this.browse_species.Multiline = true;
            this.browse_species.Name = "browse_species";
            this.browse_species.Size = new System.Drawing.Size(306, 43);
            this.browse_species.TabIndex = 13;
            this.browse_species.Text = "Load monoisotopic mass file";
            this.browse_species.TextChanged += new System.EventHandler(this.browse_species_TextChanged);
            // 
            // ms_reset
            // 
            this.ms_reset.Location = new System.Drawing.Point(6, 427);
            this.ms_reset.Margin = new System.Windows.Forms.Padding(2);
            this.ms_reset.Name = "ms_reset";
            this.ms_reset.Size = new System.Drawing.Size(86, 30);
            this.ms_reset.TabIndex = 17;
            this.ms_reset.Text = "Reset";
            this.ms_reset.UseVisualStyleBackColor = true;
            this.ms_reset.Click += new System.EventHandler(this.ms_reset_Click);
            // 
            // ms_search
            // 
            this.ms_search.Location = new System.Drawing.Point(431, 427);
            this.ms_search.Margin = new System.Windows.Forms.Padding(2);
            this.ms_search.Name = "ms_search";
            this.ms_search.Size = new System.Drawing.Size(118, 30);
            this.ms_search.TabIndex = 4;
            this.ms_search.Text = "Search";
            this.ms_search.UseVisualStyleBackColor = true;
            this.ms_search.Click += new System.EventHandler(this.ms_search_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.msms_reset);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.MS2_search);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(560, 487);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "MS/MS search";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // msms_reset
            // 
            this.msms_reset.Location = new System.Drawing.Point(4, 439);
            this.msms_reset.Name = "msms_reset";
            this.msms_reset.Size = new System.Drawing.Size(112, 34);
            this.msms_reset.TabIndex = 29;
            this.msms_reset.Text = "Reset";
            this.msms_reset.UseVisualStyleBackColor = true;
            this.msms_reset.Click += new System.EventHandler(this.msms_reset_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.msms_cid_energy);
            this.groupBox2.Controls.Add(this.groupBox5);
            this.groupBox2.Controls.Add(this.msms_min_number_frags);
            this.groupBox2.Controls.Add(this.msms_min_number_of_fragments);
            this.groupBox2.Controls.Add(this.ms_ms_ionization);
            this.groupBox2.Controls.Add(this.CID_energy);
            this.groupBox2.Location = new System.Drawing.Point(4, 271);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(550, 162);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Parameters";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // msms_cid_energy
            // 
            this.msms_cid_energy.AutoSize = true;
            this.msms_cid_energy.Location = new System.Drawing.Point(358, 116);
            this.msms_cid_energy.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.msms_cid_energy.Name = "msms_cid_energy";
            this.msms_cid_energy.Size = new System.Drawing.Size(60, 13);
            this.msms_cid_energy.TabIndex = 24;
            this.msms_cid_energy.Text = "CID energy";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Fragment_mass_tol);
            this.groupBox5.Controls.Add(this.Parent_ion_mass_tol);
            this.groupBox5.Controls.Add(this.Fragment_da);
            this.groupBox5.Controls.Add(this.Parent_da);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Location = new System.Drawing.Point(238, 17);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox5.Size = new System.Drawing.Size(308, 76);
            this.groupBox5.TabIndex = 28;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Error tolerance";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // Fragment_mass_tol
            // 
            this.Fragment_mass_tol.Location = new System.Drawing.Point(145, 47);
            this.Fragment_mass_tol.Margin = new System.Windows.Forms.Padding(2);
            this.Fragment_mass_tol.Multiline = true;
            this.Fragment_mass_tol.Name = "Fragment_mass_tol";
            this.Fragment_mass_tol.Size = new System.Drawing.Size(36, 20);
            this.Fragment_mass_tol.TabIndex = 17;
            this.Fragment_mass_tol.Text = "0.05";
            this.Fragment_mass_tol.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Fragment_mass_tol_KeyPress);
            // 
            // Parent_ion_mass_tol
            // 
            this.Parent_ion_mass_tol.Location = new System.Drawing.Point(145, 20);
            this.Parent_ion_mass_tol.Margin = new System.Windows.Forms.Padding(2);
            this.Parent_ion_mass_tol.Multiline = true;
            this.Parent_ion_mass_tol.Name = "Parent_ion_mass_tol";
            this.Parent_ion_mass_tol.Size = new System.Drawing.Size(36, 22);
            this.Parent_ion_mass_tol.TabIndex = 11;
            this.Parent_ion_mass_tol.Text = "0.05";
            this.Parent_ion_mass_tol.TextChanged += new System.EventHandler(this.Parent_ion_mass_tol_TextChanged);
            this.Parent_ion_mass_tol.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Parent_ion_mass_tol_KeyPress);
            // 
            // Fragment_da
            // 
            this.Fragment_da.FormattingEnabled = true;
            this.Fragment_da.Items.AddRange(new object[] {
            "Da",
            "ppm"});
            this.Fragment_da.Location = new System.Drawing.Point(213, 47);
            this.Fragment_da.Margin = new System.Windows.Forms.Padding(2);
            this.Fragment_da.Name = "Fragment_da";
            this.Fragment_da.Size = new System.Drawing.Size(75, 21);
            this.Fragment_da.TabIndex = 16;
            this.Fragment_da.Text = "Select";
            this.Fragment_da.SelectedIndexChanged += new System.EventHandler(this.Fragment_da_SelectedIndexChanged);
            // 
            // Parent_da
            // 
            this.Parent_da.FormattingEnabled = true;
            this.Parent_da.Items.AddRange(new object[] {
            "Da",
            "ppm"});
            this.Parent_da.Location = new System.Drawing.Point(213, 20);
            this.Parent_da.Margin = new System.Windows.Forms.Padding(2);
            this.Parent_da.Name = "Parent_da";
            this.Parent_da.Size = new System.Drawing.Size(75, 21);
            this.Parent_da.TabIndex = 18;
            this.Parent_da.Text = "Select";
            this.Parent_da.SelectedIndexChanged += new System.EventHandler(this.Parent_da_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Parent mass tolerance";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 47);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Fragment ion tolerance";
            // 
            // msms_min_number_frags
            // 
            this.msms_min_number_frags.FormattingEnabled = true;
            this.msms_min_number_frags.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.msms_min_number_frags.Location = new System.Drawing.Point(211, 113);
            this.msms_min_number_frags.Margin = new System.Windows.Forms.Padding(2);
            this.msms_min_number_frags.Name = "msms_min_number_frags";
            this.msms_min_number_frags.Size = new System.Drawing.Size(91, 21);
            this.msms_min_number_frags.TabIndex = 27;
            this.msms_min_number_frags.Text = "Select";
            // 
            // msms_min_number_of_fragments
            // 
            this.msms_min_number_of_fragments.AutoSize = true;
            this.msms_min_number_of_fragments.Location = new System.Drawing.Point(10, 116);
            this.msms_min_number_of_fragments.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.msms_min_number_of_fragments.Name = "msms_min_number_of_fragments";
            this.msms_min_number_of_fragments.Size = new System.Drawing.Size(191, 13);
            this.msms_min_number_of_fragments.TabIndex = 26;
            this.msms_min_number_of_fragments.Text = "Minimum number of fragments to match";
            // 
            // ms_ms_ionization
            // 
            this.ms_ms_ionization.Controls.Add(this.adduct_items_count);
            this.ms_ms_ionization.Controls.Add(this.msms_neg_adduct);
            this.ms_ms_ionization.Controls.Add(this.button3);
            this.ms_ms_ionization.Location = new System.Drawing.Point(5, 16);
            this.ms_ms_ionization.Margin = new System.Windows.Forms.Padding(2);
            this.ms_ms_ionization.Name = "ms_ms_ionization";
            this.ms_ms_ionization.Padding = new System.Windows.Forms.Padding(2);
            this.ms_ms_ionization.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ms_ms_ionization.Size = new System.Drawing.Size(218, 76);
            this.ms_ms_ionization.TabIndex = 25;
            this.ms_ms_ionization.TabStop = false;
            this.ms_ms_ionization.Text = "Ionization mode";
            // 
            // adduct_items_count
            // 
            this.adduct_items_count.AutoSize = true;
            this.adduct_items_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adduct_items_count.ForeColor = System.Drawing.SystemColors.Highlight;
            this.adduct_items_count.Location = new System.Drawing.Point(25, 60);
            this.adduct_items_count.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.adduct_items_count.Name = "adduct_items_count";
            this.adduct_items_count.Size = new System.Drawing.Size(79, 13);
            this.adduct_items_count.TabIndex = 2;
            this.adduct_items_count.Text = "cccccccccccc";
            this.adduct_items_count.Click += new System.EventHandler(this.adduct_items_count_Click);
            // 
            // msms_neg_adduct
            // 
            this.msms_neg_adduct.Location = new System.Drawing.Point(135, 17);
            this.msms_neg_adduct.Margin = new System.Windows.Forms.Padding(2);
            this.msms_neg_adduct.Name = "msms_neg_adduct";
            this.msms_neg_adduct.Size = new System.Drawing.Size(60, 36);
            this.msms_neg_adduct.TabIndex = 1;
            this.msms_neg_adduct.Text = "Negative";
            this.msms_neg_adduct.UseVisualStyleBackColor = true;
            this.msms_neg_adduct.Click += new System.EventHandler(this.msms_neg_adduct_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(25, 15);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(62, 37);
            this.button3.TabIndex = 0;
            this.button3.Text = "Positive";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // CID_energy
            // 
            this.CID_energy.FormattingEnabled = true;
            this.CID_energy.Items.AddRange(new object[] {
            "Low",
            "Medium",
            "High"});
            this.CID_energy.Location = new System.Drawing.Point(427, 113);
            this.CID_energy.Margin = new System.Windows.Forms.Padding(2);
            this.CID_energy.Name = "CID_energy";
            this.CID_energy.Size = new System.Drawing.Size(120, 21);
            this.CID_energy.TabIndex = 15;
            this.CID_energy.Text = "CID energy";
            this.CID_energy.SelectedIndexChanged += new System.EventHandler(this.CID_energy_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.ms_ms_load_monoisotopic_mass_label);
            this.groupBox1.Controls.Add(this.ms_ms_load_output_file_label);
            this.groupBox1.Controls.Add(this.Load_query_file_label);
            this.groupBox1.Controls.Add(this.ms_ms_species_count);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.Browse_monoisotopic_mass);
            this.groupBox1.Controls.Add(this.Load_monoisotopic_mass);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Browse_output_dir);
            this.groupBox1.Controls.Add(this.Output_dir);
            this.groupBox1.Controls.Add(this.Browse_database_dir);
            this.groupBox1.Controls.Add(this.Load_database);
            this.groupBox1.Controls.Add(this.Browse_query_file);
            this.groupBox1.Controls.Add(this.Load_query_file);
            this.groupBox1.Location = new System.Drawing.Point(4, 19);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(550, 248);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select files";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // ms_ms_load_monoisotopic_mass_label
            // 
            this.ms_ms_load_monoisotopic_mass_label.AutoSize = true;
            this.ms_ms_load_monoisotopic_mass_label.Location = new System.Drawing.Point(176, 131);
            this.ms_ms_load_monoisotopic_mass_label.Name = "ms_ms_load_monoisotopic_mass_label";
            this.ms_ms_load_monoisotopic_mass_label.Size = new System.Drawing.Size(123, 13);
            this.ms_ms_load_monoisotopic_mass_label.TabIndex = 16;
            this.ms_ms_load_monoisotopic_mass_label.Text = "Load monoisotopic mass";
            // 
            // ms_ms_load_output_file_label
            // 
            this.ms_ms_load_output_file_label.AutoSize = true;
            this.ms_ms_load_output_file_label.Location = new System.Drawing.Point(6, 212);
            this.ms_ms_load_output_file_label.Name = "ms_ms_load_output_file_label";
            this.ms_ms_load_output_file_label.Size = new System.Drawing.Size(99, 13);
            this.ms_ms_load_output_file_label.TabIndex = 15;
            this.ms_ms_load_output_file_label.Text = "Set output directory";
            // 
            // Load_query_file_label
            // 
            this.Load_query_file_label.AutoSize = true;
            this.Load_query_file_label.Location = new System.Drawing.Point(6, 35);
            this.Load_query_file_label.Name = "Load_query_file_label";
            this.Load_query_file_label.Size = new System.Drawing.Size(76, 13);
            this.Load_query_file_label.TabIndex = 14;
            this.Load_query_file_label.Text = "Load query file";
            // 
            // ms_ms_species_count
            // 
            this.ms_ms_species_count.AutoSize = true;
            this.ms_ms_species_count.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ms_ms_species_count.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.ms_ms_species_count.Location = new System.Drawing.Point(7, 134);
            this.ms_ms_species_count.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ms_ms_species_count.Name = "ms_ms_species_count";
            this.ms_ms_species_count.Size = new System.Drawing.Size(31, 13);
            this.ms_ms_species_count.TabIndex = 13;
            this.ms_ms_species_count.Text = "cvvv";
            this.ms_ms_species_count.Click += new System.EventHandler(this.ms_ms_species_count_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(5, 81);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(131, 43);
            this.button2.TabIndex = 12;
            this.button2.Text = "Select species";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Browse_monoisotopic_mass
            // 
            this.Browse_monoisotopic_mass.Location = new System.Drawing.Point(470, 151);
            this.Browse_monoisotopic_mass.Margin = new System.Windows.Forms.Padding(2);
            this.Browse_monoisotopic_mass.Name = "Browse_monoisotopic_mass";
            this.Browse_monoisotopic_mass.Size = new System.Drawing.Size(56, 27);
            this.Browse_monoisotopic_mass.TabIndex = 10;
            this.Browse_monoisotopic_mass.Text = "Browse";
            this.Browse_monoisotopic_mass.UseVisualStyleBackColor = true;
            this.Browse_monoisotopic_mass.Click += new System.EventHandler(this.Browse_monoisotopic_mass_Click);
            // 
            // Load_monoisotopic_mass
            // 
            this.Load_monoisotopic_mass.Location = new System.Drawing.Point(179, 144);
            this.Load_monoisotopic_mass.Margin = new System.Windows.Forms.Padding(2);
            this.Load_monoisotopic_mass.Multiline = true;
            this.Load_monoisotopic_mass.Name = "Load_monoisotopic_mass";
            this.Load_monoisotopic_mass.Size = new System.Drawing.Size(287, 44);
            this.Load_monoisotopic_mass.TabIndex = 9;
            this.Load_monoisotopic_mass.Text = "Load monoisotopic mass";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(146, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "OR";
            // 
            // Browse_output_dir
            // 
            this.Browse_output_dir.Location = new System.Drawing.Point(470, 205);
            this.Browse_output_dir.Margin = new System.Windows.Forms.Padding(2);
            this.Browse_output_dir.Name = "Browse_output_dir";
            this.Browse_output_dir.Size = new System.Drawing.Size(56, 27);
            this.Browse_output_dir.TabIndex = 6;
            this.Browse_output_dir.Text = "Browse";
            this.Browse_output_dir.UseVisualStyleBackColor = true;
            this.Browse_output_dir.Click += new System.EventHandler(this.Browse_output_dir_Click);
            // 
            // Output_dir
            // 
            this.Output_dir.Location = new System.Drawing.Point(113, 205);
            this.Output_dir.Margin = new System.Windows.Forms.Padding(2);
            this.Output_dir.Multiline = true;
            this.Output_dir.Name = "Output_dir";
            this.Output_dir.Size = new System.Drawing.Size(353, 28);
            this.Output_dir.TabIndex = 5;
            this.Output_dir.Text = "Output directory here";
            // 
            // Browse_database_dir
            // 
            this.Browse_database_dir.Location = new System.Drawing.Point(470, 89);
            this.Browse_database_dir.Margin = new System.Windows.Forms.Padding(2);
            this.Browse_database_dir.Name = "Browse_database_dir";
            this.Browse_database_dir.Size = new System.Drawing.Size(56, 27);
            this.Browse_database_dir.TabIndex = 4;
            this.Browse_database_dir.Text = "Browse";
            this.Browse_database_dir.UseVisualStyleBackColor = true;
            this.Browse_database_dir.Click += new System.EventHandler(this.Browse_database_dir_Click);
            // 
            // Load_database
            // 
            this.Load_database.Location = new System.Drawing.Point(179, 82);
            this.Load_database.Margin = new System.Windows.Forms.Padding(2);
            this.Load_database.Multiline = true;
            this.Load_database.Name = "Load_database";
            this.Load_database.Size = new System.Drawing.Size(287, 42);
            this.Load_database.TabIndex = 3;
            this.Load_database.Text = "Set database directory";
            this.Load_database.TextChanged += new System.EventHandler(this.Load_database_TextChanged);
            // 
            // Browse_query_file
            // 
            this.Browse_query_file.Location = new System.Drawing.Point(472, 28);
            this.Browse_query_file.Margin = new System.Windows.Forms.Padding(2);
            this.Browse_query_file.Name = "Browse_query_file";
            this.Browse_query_file.Size = new System.Drawing.Size(56, 27);
            this.Browse_query_file.TabIndex = 2;
            this.Browse_query_file.Text = "Browse";
            this.Browse_query_file.UseVisualStyleBackColor = true;
            this.Browse_query_file.Click += new System.EventHandler(this.Browse_query_file_Click);
            // 
            // Load_query_file
            // 
            this.Load_query_file.Location = new System.Drawing.Point(94, 28);
            this.Load_query_file.Margin = new System.Windows.Forms.Padding(2);
            this.Load_query_file.Multiline = true;
            this.Load_query_file.Name = "Load_query_file";
            this.Load_query_file.Size = new System.Drawing.Size(373, 28);
            this.Load_query_file.TabIndex = 1;
            this.Load_query_file.Text = "Query file here";
            this.Load_query_file.TextChanged += new System.EventHandler(this.Load_query_file_TextChanged);
            // 
            // MS2_search
            // 
            this.MS2_search.Location = new System.Drawing.Point(438, 437);
            this.MS2_search.Margin = new System.Windows.Forms.Padding(2);
            this.MS2_search.Name = "MS2_search";
            this.MS2_search.Size = new System.Drawing.Size(112, 39);
            this.MS2_search.TabIndex = 21;
            this.MS2_search.Text = "Search";
            this.MS2_search.UseVisualStyleBackColor = true;
            this.MS2_search.Click += new System.EventHandler(this.button4_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage4.Controls.Add(this.richTextBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(560, 487);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "About";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(3, 59);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(554, 281);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Browse_query_file_dialog
            // 
            this.Browse_query_file_dialog.FileName = "openFileDialog1";
            // 
            // Load_mono_file
            // 
            this.Load_mono_file.FileName = "openFileDialog1";
            // 
            // ms_load_input_file_dialog
            // 
            this.ms_load_input_file_dialog.FileName = "ms_load_input_file_dlg";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MS2Compound.Properties.Resources.MS2Compound_logo;
            this.pictureBox1.Location = new System.Drawing.Point(9, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(208, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 638);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "MS2Compound";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ms_ionization_mode.ResumeLayout(false);
            this.ms_ionization_mode.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ms_ms_ionization.ResumeLayout(false);
            this.ms_ms_ionization.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Browse_output_dir;
        private System.Windows.Forms.TextBox Output_dir;
        private System.Windows.Forms.Button Browse_database_dir;
        private System.Windows.Forms.TextBox Load_database;
        private System.Windows.Forms.Button Browse_query_file;
        private System.Windows.Forms.TextBox Load_query_file;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Parent_ion_mass_tol;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Parent_da;
        private System.Windows.Forms.TextBox Fragment_mass_tol;
        private System.Windows.Forms.ComboBox Fragment_da;
        private System.Windows.Forms.ComboBox CID_energy;
        private System.Windows.Forms.Button MS2_search;
        private System.Windows.Forms.OpenFileDialog Browse_query_file_dialog;
        private System.Windows.Forms.FolderBrowserDialog Browse_dir_dialog;
        private System.Windows.Forms.Button Browse_monoisotopic_mass;
        private System.Windows.Forms.TextBox Load_monoisotopic_mass;
        private System.Windows.Forms.OpenFileDialog Load_mono_file;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label ms_lbl_molecular_weight_tolerance;
        private System.Windows.Forms.TextBox ms_mol_weight_tolerance;
        private System.Windows.Forms.Button ms_search;
        private System.Windows.Forms.ComboBox ms_select_unit;
        private System.Windows.Forms.Label ms_ms_species_count;
        private System.Windows.Forms.Label adduct_items_count;
        private System.Windows.Forms.Button ms_reset;
        private System.Windows.Forms.Button ms_select_species;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button ms_browse;
        private System.Windows.Forms.TextBox browse_species;
        private System.Windows.Forms.TextBox ms_set_output_dir;
        private System.Windows.Forms.Button ms_browse_op_dir;
        private System.Windows.Forms.OpenFileDialog ms_load_input_file_dialog;
        private System.Windows.Forms.Label ms_select_species_lbl;
        private System.Windows.Forms.Label ms_adduct_count;
        private System.Windows.Forms.GroupBox ms_ms_ionization;
        private System.Windows.Forms.GroupBox ms_ionization_mode;
        private System.Windows.Forms.Button ms_negative_click;
        private System.Windows.Forms.Button ms_positive_click;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button msms_neg_adduct;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox msms_min_number_frags;
        private System.Windows.Forms.Label msms_min_number_of_fragments;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label msms_cid_energy;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label Create_Custom_DB_upload_label;
        private System.Windows.Forms.TextBox Create_Custom_DB_upload_path;
        private System.Windows.Forms.Button Create_Custom_DB_upload;
        private System.Windows.Forms.CheckBox Create_Custom_DB_fragment_check;
        private System.Windows.Forms.ComboBox Create_Custom_DB_list_of_fragments;
        private System.Windows.Forms.CheckBox Create_Custom_DB_calc_monoisotopicmass;
        private System.Windows.Forms.ComboBox Create_Custom_DB_set_spectra_type;
        private System.Windows.Forms.Label Create_Custom_DB_spectra_type_label;
        private System.Windows.Forms.Button Create_Custom_DB_submit;
        private System.Windows.Forms.OpenFileDialog Create_Custom_DB_browse_file;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Create_Custom_DB_set_op_dir_label;
        private System.Windows.Forms.TextBox Create_Custom_DB_set_op_dir;
        private System.Windows.Forms.Button Create_Custom_DB_browse_op_dir;
        private System.Windows.Forms.FolderBrowserDialog Create_Custom_DB_browse_op_path;
        private System.Windows.Forms.Label ms_ms_load_monoisotopic_mass_label;
        private System.Windows.Forms.Label ms_ms_load_output_file_label;
        private System.Windows.Forms.Label Load_query_file_label;
        private System.Windows.Forms.Label ms_label_or;
        private System.Windows.Forms.Button ms_browse_input_file;
        private System.Windows.Forms.TextBox ms_set_input_file;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button msms_reset;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

