﻿namespace Test_delete
{
    partial class Select_adducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Select_adducts));
            this.Select_adduct_box = new System.Windows.Forms.CheckedListBox();
            this.Select_all_adducts = new System.Windows.Forms.Button();
            this.submit_adducts = new System.Windows.Forms.Button();
            this.Close_adducts = new System.Windows.Forms.Button();
            this.adducts_clear_all = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Select_adduct_box
            // 
            this.Select_adduct_box.FormattingEnabled = true;
            this.Select_adduct_box.Location = new System.Drawing.Point(2, 8);
            this.Select_adduct_box.Margin = new System.Windows.Forms.Padding(2);
            this.Select_adduct_box.Name = "Select_adduct_box";
            this.Select_adduct_box.Size = new System.Drawing.Size(353, 349);
            this.Select_adduct_box.TabIndex = 0;
            // 
            // Select_all_adducts
            // 
            this.Select_all_adducts.Location = new System.Drawing.Point(2, 370);
            this.Select_all_adducts.Margin = new System.Windows.Forms.Padding(2);
            this.Select_all_adducts.Name = "Select_all_adducts";
            this.Select_all_adducts.Size = new System.Drawing.Size(65, 24);
            this.Select_all_adducts.TabIndex = 1;
            this.Select_all_adducts.Text = "Select All";
            this.Select_all_adducts.UseVisualStyleBackColor = true;
            this.Select_all_adducts.Click += new System.EventHandler(this.Select_all_adducts_Click);
            // 
            // submit_adducts
            // 
            this.submit_adducts.Location = new System.Drawing.Point(213, 370);
            this.submit_adducts.Margin = new System.Windows.Forms.Padding(2);
            this.submit_adducts.Name = "submit_adducts";
            this.submit_adducts.Size = new System.Drawing.Size(68, 24);
            this.submit_adducts.TabIndex = 2;
            this.submit_adducts.Text = "Submit";
            this.submit_adducts.UseVisualStyleBackColor = true;
            this.submit_adducts.Click += new System.EventHandler(this.submit_adducts_Click);
            // 
            // Close_adducts
            // 
            this.Close_adducts.Location = new System.Drawing.Point(285, 370);
            this.Close_adducts.Margin = new System.Windows.Forms.Padding(2);
            this.Close_adducts.Name = "Close_adducts";
            this.Close_adducts.Size = new System.Drawing.Size(70, 24);
            this.Close_adducts.TabIndex = 3;
            this.Close_adducts.Text = "Close";
            this.Close_adducts.UseVisualStyleBackColor = true;
            this.Close_adducts.Click += new System.EventHandler(this.Close_adducts_Click);
            // 
            // adducts_clear_all
            // 
            this.adducts_clear_all.Location = new System.Drawing.Point(71, 370);
            this.adducts_clear_all.Margin = new System.Windows.Forms.Padding(2);
            this.adducts_clear_all.Name = "adducts_clear_all";
            this.adducts_clear_all.Size = new System.Drawing.Size(62, 24);
            this.adducts_clear_all.TabIndex = 4;
            this.adducts_clear_all.Text = "Clear All";
            this.adducts_clear_all.UseVisualStyleBackColor = true;
            this.adducts_clear_all.Click += new System.EventHandler(this.adducts_clear_all_Click);
            // 
            // Select_adducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 404);
            this.Controls.Add(this.adducts_clear_all);
            this.Controls.Add(this.Close_adducts);
            this.Controls.Add(this.submit_adducts);
            this.Controls.Add(this.Select_all_adducts);
            this.Controls.Add(this.Select_adduct_box);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Select_adducts";
            this.Text = "Select_adducts";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Select_adducts_FormClosing);
            this.Load += new System.EventHandler(this.Select_adducts_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckedListBox Select_adduct_box;
        private System.Windows.Forms.Button Select_all_adducts;
        private System.Windows.Forms.Button submit_adducts;
        private System.Windows.Forms.Button Close_adducts;
        private System.Windows.Forms.Button adducts_clear_all;
    }
}