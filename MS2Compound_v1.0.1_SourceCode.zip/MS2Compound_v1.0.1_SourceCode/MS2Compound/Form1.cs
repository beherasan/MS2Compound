﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;
using System.IO;
using System.Windows.Forms.VisualStyles;

namespace Test_delete
{
    public partial class Form1 : Form
    {
        public string perl_path = System.IO.Directory.GetCurrentDirectory() ;
        public static string ionization_mode = "";
        public static int adduct_count = 0;
        public static int adduct_selected = 0;
        public static int adduct_type = 0;
        public static int active_tab = 0;
        public static string database_file = "";
        public static string query_file = "";
        public static string query_file_ms = "";
        public static string output_dir_file = ""; //ms-ms
        public static string ms_output_dir_file = ""; //ms
        public static string mono_isotopic_mass = "";
        public static int species_select_status = 0;
        public string cmd = "";
        public string adduct_call = "";
        public string species_call = "";
        public int ionization_mode_local = 2;
        public static string ms_compound_fldr = ""; //write the folder in incremental order ex ms2compund1, 2 ...


        //For MS
        public static string ms_set_ip_file = "";

        public Form1()
        {
            /*
           if (Select_species.selected_item.Count() != 0)
            {
               for (int i = 0;  i <= Select_species.selected_item.Count() - 1 ; i++)
                {
                    MessageBox.Show(Select_species.selected_item[i]);
                }
            } */
  
            InitializeComponent();
            //For MS/MS
            Parent_da.SelectedItem = "Da";
            Fragment_da.SelectedItem = "Da";
            ms_select_unit.SelectedItem = "Da";
            Load_database.Text = Select_species.database_file_species;
            Load_query_file.Text = Select_species.query_file_species;
            Output_dir.Text = Select_species.output_dir_file_species;
            Load_monoisotopic_mass.Text = Select_species.mono_isotopic_mass_species;

            string terminal_path = System.IO.Directory.GetCurrentDirectory() + "\\" + "terminal.exe";
            /*Setting the Da for error tolerance 1) for MS/MS 2) for MS */
            Parent_da.SelectedItem = "Da";
            Fragment_da.SelectedItem = "Da";
            CID_energy.SelectedItem = "Low";
            msms_min_number_frags.SelectedItem = "1";
            if (Select_species.active_tab_species != 0)
            {
                tabControl1.SelectedIndex = Select_species.active_tab_species;

            }
            else
            {
                tabControl1.SelectedIndex = Select_adducts.active_tab_species;
            }


            //ms
            if (Select_species.ms_query_file_species.ToString() != "")
            {
                ms_set_input_file.Text = Select_species.ms_query_file_species;
                
            }
            else
            {
                ms_set_input_file.Text = "Load input file";
            }
            //msms
            if (Select_species.query_file_species.ToString() != "") 
            {
                Load_query_file.Text = Select_species.query_file_species;
            }
            else
            {
                Load_query_file.Text = "Load input file";
            }
            //ms
            if (Select_species.ms_output_dir_file_species.ToString() != "") 
            {
                ms_set_output_dir.Text = Select_species.ms_output_dir_file_species;
            }
            else
            {
                ms_set_output_dir.Text = "Set the output directory";
            }
            //msms
            if (Select_species.output_dir_file_species.ToString() != "") 
            {
                Output_dir.Text = Select_species.ms_compound_fldr;
            }
            else
            {
                Output_dir.Text = "Set the output directory";
            }
            //ms && //msms together in statement
            if (Select_species.database_file_species.ToString() != "") 
            {
                browse_species.Text = Select_species.database_file_species;
                Load_database.Text = Select_species.database_file_species;
            }
            else
            {
                browse_species.Text = "Load monoisotopic mass file";
                Load_database.Text = "Load database directory";

            }

            if (Select_adducts.database_file_species.ToString() != "") 
            {
                browse_species.Text = Select_adducts.database_file_species;
                Load_database.Text = Select_adducts.database_file_species;

            }
            else
            {
                browse_species.Text = "Load monoisotopic mass file";
                Load_database.Text = "Load database directory";

            }


            //ms
            if (Select_adducts.input_query_file_ms.ToString() != "" && Select_species.ms_query_file_species.ToString() == "")
            {
                ms_set_input_file.Text = Select_adducts.input_query_file_ms;
            }
            else
            {

            }
            //msms
            if (Select_adducts.query_file_species.ToString() != "" && Select_species.query_file_species.ToString() == "")
            {
                Load_query_file.Text = Select_adducts.query_file_species;
            }
            else
            {

            }
            //ms
            if (Select_adducts.ms_output_dir_file_species.ToString() != "" && Select_species.ms_output_dir_file_species.ToString() == "")
            {
                ms_set_output_dir.Text = Select_adducts.ms_output_dir_file_species;
            }
            else
            {

            }
            //msms
            if (Select_adducts.output_dir_file_species.ToString() != "" && Select_species.output_dir_file_species.ToString() == "")
            {
                Output_dir.Text = Select_adducts.output_dir_file_species;
            }
            else
            {
                
            }
            //ms && //msms together in statement
            if(Select_adducts.database_file_species.ToString() != "" && Select_species.database_file_species.ToString() == "")
            {
                browse_species.Text = Select_adducts.database_file_species;
                Load_database.Text = Select_adducts.database_file_species;
                
            }
            else
            {

            }


            Create_Custom_DB_list_of_fragments.Enabled = false;
            Create_Custom_DB_set_spectra_type.Enabled = false;

            if (Select_species.mono_isotopic_mass_species.ToString() != "")
            {
                Load_monoisotopic_mass.Enabled = true;
                Browse_monoisotopic_mass.Enabled = true;
                ms_ms_load_monoisotopic_mass_label.Enabled = true;
                Load_monoisotopic_mass.Text = Select_species.mono_isotopic_mass_species;
            }
            else
            {
                Load_monoisotopic_mass.Text = "Load monoisotopic mass";
                Load_monoisotopic_mass.Enabled = false;
                Browse_monoisotopic_mass.Enabled = false;
                ms_ms_load_monoisotopic_mass_label.Enabled = false;
                
            }
            if(Select_adducts.mono_isotopic_mass_species.ToString() != "" && Select_species.mono_isotopic_mass_species.ToString() == "")
            {
                Load_monoisotopic_mass.Enabled = true;
                Browse_monoisotopic_mass.Enabled = true;
                ms_ms_load_monoisotopic_mass_label.Enabled = true;
                Load_monoisotopic_mass.Text = Select_adducts.mono_isotopic_mass_species;
            }
            else
            {
                //Load_monoisotopic_mass.Enabled = false;
                //Browse_monoisotopic_mass.Enabled = false;
                //ms_ms_load_monoisotopic_mass_label.Enabled = false;
            }

            //ms
            if (Select_species.selected_item.Count() > 0)
            {
                browse_species.Text = "Load monoisotopic mass file";
                Load_database.Text = "Load database directory";
                Select_species.database_file_species = "";
                Load_monoisotopic_mass.Text = "Load monoisotopic mass";
                Load_monoisotopic_mass.Enabled = false;
                ms_ms_load_monoisotopic_mass_label.Enabled = false;
                Browse_monoisotopic_mass.Enabled = false;
            }
            else
            {
                //Select_species.selected_item.Clear();
                //Select_species.selected_items.Clear();
                //Select_species.int_items.Clear();
            }
            if (System.IO.Directory.Exists(Select_adducts.database_file_species.ToString()))
            {
                Load_monoisotopic_mass.Enabled = true;
                ms_ms_load_monoisotopic_mass_label.Enabled = true;
                Browse_monoisotopic_mass.Enabled = true;
            }
            else
            {
                Load_monoisotopic_mass.Enabled = false;
                ms_ms_load_monoisotopic_mass_label.Enabled = false;
                Browse_monoisotopic_mass.Enabled = false;
            }

            ms_ms_species_count.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
            ms_select_species_lbl.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
            adduct_items_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count +  " adducts";
            ms_adduct_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count().ToString() + " adducts";

           
        }


        public Process ProcessRunner(string cmd)
        {
            System.Diagnostics.Process prcs = new System.Diagnostics.Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = perl_path + "\\"+ "perl.exe ";
            startInfo.Arguments = cmd;
            prcs.StartInfo = startInfo;
            prcs.Start();           
            prcs.WaitForExit();
            return prcs;
        }

        public Process ProcessRunner_terminal(string cmd)
        {
            System.Diagnostics.Process prcs = new System.Diagnostics.Process();
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = cmd;
            prcs.StartInfo = startInfo;
            prcs.Start();
            prcs.WaitForExit();
            return prcs;
        }

        private void button4_Click(object sender, EventArgs e)
        {
           // MessageBox.Show(ms_compound_fldr);
            call_adducts();
            call_species();
            string cmd = "";
            if (System.IO.File.Exists(Load_query_file.Text) && !Load_query_file.Text.Contains(" "))
            {
                if (System.IO.Directory.Exists(Output_dir.Text) && !Output_dir.Text.Contains(" "))
                {
                    if (System.IO.File.Exists(ms_compound_fldr + "\\" + "parameters_MSMS_search.log"))
                    {
                        System.IO.File.Delete(ms_compound_fldr + "\\" + "parameters_MSMS_search.log");
                    }
                    if (adduct_call != "0")
                    {
                        if (species_call != "0")
                        {

                            cmd = "/C " + System.IO.Directory.GetCurrentDirectory() + "\\perl\\bin\\" + "perl.exe " + System.IO.Directory.GetCurrentDirectory() + "\\Scripts\\MS2CompoundInBuiltDB_MSMS.pl " + " " + Load_query_file.Text + " " + Select_adducts.adduct_type_a + " " + adduct_call + " " + species_call + " " + Parent_da.GetItemText(Parent_da.SelectedItem) + " " + Parent_ion_mass_tol.Text + " " + Fragment_da.GetItemText(Fragment_da.SelectedItem) + " " + Fragment_mass_tol.Text + " " + msms_min_number_frags.GetItemText(msms_min_number_frags.SelectedItem) + " " + CID_energy.GetItemText(CID_energy.SelectedItem) + " " + ms_compound_fldr + " " + System.IO.Directory.GetCurrentDirectory() + "\\" + "Database\\UpdatedMSMS" + " " + System.IO.Directory.GetCurrentDirectory() + "\\Database";
                            //Load_database.Text = cmd;
                            ProcessRunner_terminal(cmd);
                            MessageBox.Show("Command completed successfully");
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "#FILES " + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Input file = " + Load_query_file.Text + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Output directory = " + ms_compound_fldr + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Compounds assigned (Text) file = " + ms_compound_fldr + "\\Assigned.txt" + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Compounds assigned (HTML) file = " + ms_compound_fldr + "\\Assigned.html" + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Unassigned precursor mass (MGF) file = " + ms_compound_fldr + "\\Unassigned.mgf" + Environment.NewLine + Environment.NewLine);


                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "#PARAMETERS " + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Ionization mode = " + Select_adducts.adduct_type_a + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Adducts selected = " + adduct_call + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Species selected = " + species_call + Environment.NewLine);
                            //  System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters.log", "Precursor mass tolerance: " + species_call + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Precursor mass tolerance = " + Parent_ion_mass_tol.Text + " " + Parent_da.GetItemText(Parent_da.SelectedItem) + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Fragment mass tolerance = " + Fragment_mass_tol.Text + " " + Fragment_da.GetItemText(Fragment_da.SelectedItem) + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Minimum number of matched Fragments = " + msms_min_number_frags.GetItemText(msms_min_number_frags.SelectedItem) + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "CID energy selected = " + CID_energy.GetItemText(CID_energy.SelectedItem) + Environment.NewLine);

                            Select_species.selected_item.Clear();
                            Select_species.selected_items.Clear();
                            Select_species.int_items.Clear();
                            Select_adducts.selected_adduct_items.Clear();
                            ms_ms_species_count.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
                            adduct_items_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count().ToString() + " adducts";


                        }
                        else
                        {
                            if (System.IO.Directory.Exists(Load_database.Text) && !Load_database.Text.Contains(" "))
                            {
                                if (System.IO.File.Exists(Load_monoisotopic_mass.Text) && !Load_monoisotopic_mass.Text.Contains(" "))
                                {
                                    cmd = "/C " + System.IO.Directory.GetCurrentDirectory() + "\\perl\\bin\\" + "perl.exe " + System.IO.Directory.GetCurrentDirectory() + "\\Scripts\\MS2CompoundCustomDB_MSMS.pl " + Load_query_file.Text + " " + Select_adducts.adduct_type_a + " " + adduct_call + " " + Load_database.Text + " " + Parent_da.GetItemText(Parent_da.SelectedItem) + " " + Parent_ion_mass_tol.Text + " " + Fragment_da.GetItemText(Fragment_da.SelectedItem) + " " + Fragment_mass_tol.Text + " " + msms_min_number_frags.GetItemText(msms_min_number_frags.SelectedItem) + " " + CID_energy.GetItemText(CID_energy.SelectedItem) + " " + ms_compound_fldr + " " + Load_monoisotopic_mass.Text;
                                    //Load_database.Text = cmd;
                                    ProcessRunner_terminal(cmd);
                                    MessageBox.Show("Command completed successfully");
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "#FILES " + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Input file = " + Load_query_file.Text + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Output directory = " + ms_compound_fldr + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Compounds assigned (Text) file = " + ms_compound_fldr + "\\Assigned.txt" + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Compounds assigned (HTML) file = " + ms_compound_fldr + "\\Assigned.html" + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Unassigned precursor mass (MGF) file =" + ms_compound_fldr + "\\Unassigned.mgf" + Environment.NewLine + Environment.NewLine);


                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "#PARAMETERS " + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Ionization mode = " + Select_adducts.adduct_type_a + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Adducts selected = " + adduct_call + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Reference database diretcory = " + Load_database.Text + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Monoisotopic mass file = " + Load_monoisotopic_mass.Text + Environment.NewLine);
                                    //  System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters.log", "Precursor mass tolerance: " + species_call + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Precursor mass tolerance = " + Parent_ion_mass_tol.Text + " " + Parent_da.GetItemText(Parent_da.SelectedItem) + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Fragment mass tolerance = " + Fragment_mass_tol.Text + " " + Fragment_da.GetItemText(Fragment_da.SelectedItem) + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "Minimum number of matched Fragments = " + msms_min_number_frags.GetItemText(msms_min_number_frags.SelectedItem) + Environment.NewLine);
                                    System.IO.File.AppendAllText(ms_compound_fldr + "/" + "parameters_MSMS_search.log", "CID energy selected = " + CID_energy.GetItemText(CID_energy.SelectedItem) + Environment.NewLine);

                                    Select_species.selected_item.Clear();
                                    Select_species.selected_items.Clear();
                                    Select_species.int_items.Clear();
                                    Select_adducts.int_items.Clear();
                                    Select_adducts.selected_adduct_items.Clear();
                                    ms_ms_species_count.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
                                    adduct_items_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count().ToString() + " adducts";


                                }
                                else
                                {
                                    if(!System.IO.File.Exists(Load_monoisotopic_mass.Text))
                                    {
                                        MessageBox.Show("Please upload monoisotopic file ");
                                    }
                                    else
                                    {
                                        MessageBox.Show("Please avoid spaces in monoisotopic file path or name");
                                    }
                                }
                            }
                            else
                            {
                                if(!System.IO.Directory.Exists(Load_database.Text))
                                {
                                    MessageBox.Show("Please select the reference directory");
                                }
                                else
                                {
                                    MessageBox.Show("Please avoid spaces in reference directory path or folder name");
                                }
                            }
                        }

                    }
                    else
                    {
                        MessageBox.Show("Please select ionization mode and adducts");
                    }
                    
                }
                else
                {
                    if(!System.IO.Directory.Exists(Output_dir.Text))
                    {
                        MessageBox.Show("Please set the output directory");
                    }
                    else
                    {
                        MessageBox.Show("Please avoid spaces in output directory path or folder name");
                    }
                }
            }
            else
            {
                if(!System.IO.File.Exists(Load_query_file.Text))
                {
                    MessageBox.Show("Please select the input file");
                }
                else
                {
                    MessageBox.Show("Please avoid spaces in input file path or name");
                }
            }
            
        }

        private void Load_database_TextChanged(object sender, EventArgs e)
        {

        }

        private void Browse_query_file_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd_reference_fasta = new OpenFileDialog();
            Browse_query_file_dialog.Filter = "MGF file (*.mgf)|*.mgf";
            if (Browse_query_file_dialog.ShowDialog() == DialogResult.OK)
            {
                Load_query_file.Text = Browse_query_file_dialog.FileName;
                query_file = Browse_query_file_dialog.FileName;
            }
        }

        private void Browse_database_dir_Click(object sender, EventArgs e)
        {
            if (Browse_dir_dialog.ShowDialog() == DialogResult.OK)
            {
                Load_database.Text = Browse_dir_dialog.SelectedPath;
                database_file = Browse_dir_dialog.SelectedPath;
            }
            Load_monoisotopic_mass.Enabled = true;
            Browse_monoisotopic_mass.Enabled = true;
            ms_ms_load_monoisotopic_mass_label.Enabled = true;
            Select_species.int_items.Clear();
            Select_species.selected_item.Clear();
            Select_species.selected_items.Clear();
            ms_ms_species_count.Text = "You have selected " + Select_species.int_items.Count.ToString() + " species";
            
        }

        private void Browse_output_dir_Click(object sender, EventArgs e)
        {
            Output_dir.Text = "";
            if (Browse_dir_dialog.ShowDialog() == DialogResult.OK)
            {
                Output_dir.Text = Browse_dir_dialog.SelectedPath;// + ms_compound_fldr;
                output_dir_file = Browse_dir_dialog.SelectedPath;
            }

            List<int> cnt = new List<int> { };
            var max = 0;
            var dirs = System.IO.Directory.GetDirectories(Output_dir.Text + '\\');
            foreach (var iter in dirs)
            {
                string[] spl = iter.Split('\\');
                if (spl[spl.Length - 1] == "MS2Compound_OUTPUT")
                {
                    cnt.Add(0);
                }
                else if ((spl[spl.Length - 1].Contains("MS2Compound_OUTPUT")))
                {
                    cnt.Add(int.Parse(spl[spl.Length - 1].Split('_')[2]));
                    //MessageBox.Show(int.Parse(spl[spl.Length - 1].Split('_')[2]).ToString());
                    if(int.Parse(spl[spl.Length - 1].Split('_')[2]) > max)
                    {
                        max = int.Parse(spl[spl.Length - 1].Split('_')[2]);
                    }
                }
               
            }


            if (max > 0)
            {
                //int incs = cnt[cnt.Count - 1] + 1;
                int incs = max + 1;
                System.IO.Directory.CreateDirectory(Output_dir.Text  + "\\"+ "MS2Compound_OUTPUT_" + incs.ToString());
                ms_compound_fldr = Output_dir.Text + "\\" + "MS2Compound_OUTPUT_" + incs.ToString();
            }
            else
            {
                System.IO.Directory.CreateDirectory(Output_dir.Text + "\\" + "MS2Compound_OUTPUT");
                ms_compound_fldr = Output_dir.Text + "\\" + "MS2Compound_OUTPUT";
            }
        }

        private void Browse_monoisotopic_mass_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd_reference_fasta = new OpenFileDialog();
            if (Load_mono_file.ShowDialog() == DialogResult.OK)
            {
                Load_monoisotopic_mass.Text = Load_mono_file.FileName;
                mono_isotopic_mass = Load_mono_file.FileName;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            List<int> cnt = new List<int> { };
            var dirs = System.IO.Directory.GetDirectories(@"D:\MS2Compound\");
            foreach(var iter in dirs)
            {
                string[] spl = iter.Split('\\');
                if (spl[spl.Length - 1] == "MS2Compound")
                {
                    cnt.Add(0);
                }
                else if ((spl[spl.Length - 1].Contains("MS2Compound_")))
                {
                    cnt.Add(int.Parse(spl[spl.Length - 1].Split('_')[1]));
                }

                }
            if (cnt.Count > 0)
            {
                int incs = cnt[cnt.Count - 1] + 1;

                System.IO.Directory.CreateDirectory(@"D:\MS2Compound\" + "MS2Compound_" + incs.ToString());
            }
            else
            {
                System.IO.Directory.CreateDirectory(@"D:\MS2Compound\" + "MS2Compound");
            }

        }
       
        private void Parent_ion_mass_tol_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Parent_ion_mass_tol_KeyPress(object sender, KeyPressEventArgs e)
        {
            //e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void Fragment_mass_tol_KeyPress(object sender, KeyPressEventArgs e)
        {
            //e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Select_species.selected_items.Clear();
            Select_species.selected_item.Clear();
            Select_species.int_items.Clear();
            species_call = "0";
            Select_species sp = new Select_species();
            sp.Show();
            active_tab = tabControl1.SelectedIndex;
            this.Hide();
            Load_database.Text = "Load database directory";
            Select_species.database_file_species = "";
            Select_adducts.database_file_species = "";
            database_file = "";
            Select_species.selected_item = new List<string>();


        }

        private void Ionization_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            active_tab = tabControl1.SelectedIndex;
            //adduct_selected = Ionization.SelectedItem.ToString();
            Select_adducts adds = new Select_adducts();
            adds.Show();
            this.Hide();

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            Select_adducts.int_items.Clear();
            Select_species.int_items.Clear();

            Select_species.selected_item.Clear();
            Select_species.selected_items.Clear();
            Select_adducts.selected_adduct_items.Clear();

            ms_ms_species_count.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
            ms_select_species_lbl.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";

            adduct_items_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count + " adducts";
            ms_adduct_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count().ToString() + " adducts";

            ms_set_input_file.Text = "Load input file";
            browse_species.Text = "Load monoisotopic mass file";
            ms_set_output_dir.Text = "Set output directory";

            Load_query_file.Text = "Query file here";
            Load_database.Text = "Load database directory";
            Output_dir.Text = "Output directory here";
            Load_monoisotopic_mass.Text = "Load monoisotopic mass";
            Load_monoisotopic_mass.Enabled = false;
            ms_ms_load_monoisotopic_mass_label.Enabled = false;
            Browse_monoisotopic_mass.Enabled = false;
            database_file = "";
            query_file_ms = "";
            ms_output_dir_file = "";
            query_file = "";
            output_dir_file = "";
            Select_species.active_tab_species = tabControl1.SelectedIndex;

            Select_species.database_file_species = "";
            Select_species.query_file_species = "";
            Select_species.ms_compound_fldr = "";
            Select_species.mono_isotopic_mass_species = "";
            Select_species.ms_output_dir_file_species = "";
            Select_species.output_dir_file_species = "";
            Select_species.ms_query_file_species = "";


            Select_adducts.database_file_species = "";
            Select_adducts.query_file_species = ""; //ms-ms
            Select_adducts.input_query_file_ms = ""; //ms
            Select_adducts.output_dir_file_species = ""; //ms-ms
            Select_adducts.ms_output_dir_file_species = ""; //ms
            Select_adducts.mono_isotopic_mass_species = "";
            Select_adducts.ionization_mode_adduct = "";
            Select_adducts.ion_mode_add = ""; // for storing the string ex: positive, negative
            Select_adducts.load_query_file_ms = "";
            


            if (tabControl1.SelectedTab == tabControl1.TabPages["tabPage2"])
            {
             
                //MessageBox.Show("Test");
            }
        }

        private void ms_ms_species_count_Click(object sender, EventArgs e)
        {
            string a = "";
            for (int i = 0; i < Select_species.int_items.Count(); i++)
            {
                if (a.Length > 0)
                {
                    a = a + ";" + Select_species.int_items[i].Split(':')[1];
                }
                else
                {
                    a = a + Select_species.int_items[i].Split(':')[1];
                }
            }
            MessageBox.Show(a);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (Process proc in Process.GetProcessesByName("MS2Compound"))
            {
                proc.Kill();
            }
        }

        private void ms_browse_Click(object sender, EventArgs e)
        {
            if (ms_load_input_file_dialog.ShowDialog() == DialogResult.OK)            
            {
                browse_species.Text = ms_load_input_file_dialog.FileName;
                database_file = ms_load_input_file_dialog.FileName;

            }
            Load_monoisotopic_mass.Visible = true;
            Browse_monoisotopic_mass.Visible = true;
            
            Select_species.selected_item.Clear();
            Select_species.selected_items.Clear();
            Select_species.int_items.Clear();
            species_uniqueLst.Clear();
            ms_ms_species_count.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
            ms_select_species_lbl.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
            //species_call = "0";
        }

        private void ms_browse_input_file_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofds = new OpenFileDialog();
            ms_load_input_file_dialog.Filter = "Text file (*.txt)|*.txt";
            
            if (ms_load_input_file_dialog.ShowDialog() == DialogResult.OK)
            {
                ms_set_input_file.Text = ms_load_input_file_dialog.FileName;
                ms_set_ip_file = ms_set_input_file.Text;

            }
            
        }

        private void ms_select_species_Click(object sender, EventArgs e)
        {
            Select_species.selected_items.Clear();
            Select_species.int_items.Clear();
            species_call = "0";
            Select_species sp = new Select_species();
            sp.Show();
            active_tab = tabControl1.SelectedIndex;
            //flag_status = 1;
            this.Hide();
            Load_database.Text = "Load database directory";
            Select_species.selected_item = new List<string>();
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void ms_select_species_lbl_Click(object sender, EventArgs e)
        {
            string a = "";
            for (int i = 0; i < Select_species.int_items.Count(); i++)
            {
                if (a.Length > 0)
                {
                    a = a + ";" + Select_species.int_items[i].Split(':')[1];
                }
                else
                {
                    a = a + Select_species.int_items[i].Split(':')[1];
                }
            }
            MessageBox.Show(a);
        }

        private void adduct_items_count_Click(object sender, EventArgs e)
        {
            string a = "";
            for (int i = 0; i < Select_adducts.selected_adduct_items.Count(); i++)
            {
                if (a.Length > 1)
                {
                    a = a + ";" + Select_adducts.selected_adduct_items[i];//.Split(':')[1];
                }
                else
                {
                    a = a + Select_adducts.selected_adduct_items[i];//.Split(':')[1];
                }
            }
            MessageBox.Show(a);
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void ms_ionization_mode_SelectedIndexChanged(object sender, EventArgs e)
        {

            active_tab = tabControl1.SelectedIndex;
            Select_adducts adds = new Select_adducts();
            adds.Show();
            this.Hide();
        }
        private void ms_adduct_count_Click(object sender, EventArgs e)
        {
            string a = "";
            for (int i = 0; i < Select_adducts.selected_adduct_items.Count(); i++)
            {
                if (a.Length > 1)
                {
                    a = a + ";" + Select_adducts.selected_adduct_items[i];//.Split(':')[1];
                }
                else
                {
                    a = a + Select_adducts.selected_adduct_items[i];//.Split(':')[1];
                }
            }
            MessageBox.Show(a);
        }

        public string call_adducts()
        {
            if (Select_adducts.selected_adduct_items.Count() > 0)
            {
                for (int i = 0; i < Select_adducts.selected_adduct_items.Count(); i++)
                {
                    if (adduct_call.Length > 1)
                    {
                        adduct_call = adduct_call + ";" + Select_adducts.selected_adduct_items[i];//.Split(':')[1];
                    }
                    else
                    {
                        adduct_call = adduct_call + Select_adducts.selected_adduct_items[i];//.Split(':')[1];
                    } 
                }
                return adduct_call;
            }
            else
            {
                return adduct_call ="0";
            }
        }

        List<string> species_uniqueLst = Select_species.selected_items.Distinct().ToList();
        public string call_species()
        {
            if (species_uniqueLst.Count() > 0)
            {
                for (int i = 0; i < species_uniqueLst.Count(); i++)
                {

                    if (i == 0)
                    {
                  
                        species_call = species_call + species_uniqueLst[i].Split(':')[1].Split('_')[0].Trim();
                    }
                    else
                    {
                        species_call = species_call + "," + species_uniqueLst[i].Split(':')[1].Split('_')[0].Trim();
                    }
                }

                return species_call;
            }
            else
            {
                return species_call = "0";
            }
        }
        private void ms_search_Click(object sender, EventArgs e)
        {
            call_adducts();
            call_species();
            if (System.IO.File.Exists(ms_set_input_file.Text) && !ms_set_input_file.Text.Contains(" "))
            {
                if (System.IO.Directory.Exists(ms_set_output_dir.Text) && !ms_set_output_dir.Text.Contains(" "))
                {
                    if (System.IO.File.Exists(ms_set_output_dir.Text + "\\" + "parameters_MS_search.log"))
                    {
                        System.IO.File.Delete(ms_set_output_dir.Text + "\\" + "parameters_MS_search.log");
                    }
                    if (adduct_call != "0")
                    {
                        if (species_call != "0")
                        {

                            cmd = "--wait /C " + System.IO.Directory.GetCurrentDirectory() + "\\perl\\bin\\" + "perl.exe " + System.IO.Directory.GetCurrentDirectory() + "\\Scripts\\MS2CompoundInBuiltDB_MS.pl " + ms_set_input_file.Text + " " + Select_adducts.adduct_type_a + " " + adduct_call + " " + species_call + " " + ms_select_unit.GetItemText(ms_select_unit.SelectedItem) + " " + ms_mol_weight_tolerance.Text + " " + ms_set_output_dir.Text + "\\" + ms_compound_fldr + " " + System.IO.Directory.GetCurrentDirectory() + "\\Database";

                            ProcessRunner_terminal(cmd);

                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "#FILES " + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Input file = " + ms_set_input_file.Text + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Output directory = " + ms_set_output_dir.Text + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Compounds assigned (Text) file = " + ms_set_output_dir.Text + "\\Assigned.txt" + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Compounds assigned (HTML) file = " + ms_set_output_dir.Text + "\\Assigned.html" + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Unassigned precursor mass (Text) file = " + ms_set_output_dir.Text + "\\Unassigned.txt" + Environment.NewLine + Environment.NewLine);


                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "#PARAMETERS " + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Ionization mode = " + Select_adducts.adduct_type_a + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Adducts selected = " + adduct_call + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Species selected = " + species_call + Environment.NewLine);
                            System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Precursor mass tolerance = " + ms_mol_weight_tolerance.Text + " " + ms_select_unit.GetItemText(ms_select_unit.SelectedItem) + Environment.NewLine);


                        }
                        else
                        {
                            if (System.IO.File.Exists(browse_species.Text) && !browse_species.Text.Contains(" "))
                            {
                                cmd = "--wait /C " + System.IO.Directory.GetCurrentDirectory() + "\\perl\\bin\\" + "perl.exe " + System.IO.Directory.GetCurrentDirectory() + "\\Scripts\\MS2CompoundCustomDB_MS.pl " + ms_set_input_file.Text + " " + Select_adducts.adduct_type_a + " " + adduct_call + " " + browse_species.Text + " " + ms_select_unit.GetItemText(ms_select_unit.SelectedItem) + " " + ms_mol_weight_tolerance.Text + " " + ms_set_output_dir.Text + "\\" + ms_compound_fldr;

                                ProcessRunner_terminal(cmd);

                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "#FILES " + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Input file = " + ms_set_input_file.Text + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Output directory = " + ms_set_output_dir.Text + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Compounds assigned (Text) file = " + ms_set_output_dir.Text + "\\Assigned.txt" + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Compounds assigned (HTML) file = " + ms_set_output_dir.Text + "\\Assigned.html" + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Unassigned precursor mass (Text) file =" + ms_set_output_dir.Text + "\\Unassigned.txt" + Environment.NewLine + Environment.NewLine);

                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "#PARAMETERS " + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Ionization mode = " + Select_adducts.adduct_type_a + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Adducts selected = " + adduct_call + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Monoisotopic mass file = " + browse_species.Text + Environment.NewLine);
                                System.IO.File.AppendAllText(ms_set_output_dir.Text + "/" + "parameters_MS_search.log", "Precursor mass tolerance = " + ms_mol_weight_tolerance.Text + " " + ms_select_unit.GetItemText(ms_select_unit.SelectedItem) + Environment.NewLine);

                            }
                            else
                            {
                                if (!System.IO.File.Exists(browse_species.Text))
                                {
                                    MessageBox.Show("Please select a species list or upload the custom database");
                                }
                                else
                                {
                                    MessageBox.Show("Please avoid spaces in monoisotopic file path or name");
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select ionization mode and adducts");
                    }
                }
                else
                {
                    if (!System.IO.Directory.Exists(ms_set_output_dir.Text))
                    {
                        MessageBox.Show("Please set the output directory");
                    }
                    else
                    {
                        MessageBox.Show("Please avoid spaces in output file path or folder");
                    }
                }
            }
            else
            {
                if (!System.IO.File.Exists(ms_set_input_file.Text))
                {
                    MessageBox.Show("Please select the input file");
                }
                else
                {
                    MessageBox.Show("Please avoid spaces in input file path or name");
                }
            }
            species_call = "";          

        }
   

        private void ms_browse_op_dir_Click(object sender, EventArgs e)
        {
            if (Browse_dir_dialog.ShowDialog() == DialogResult.OK)
            {
                ms_set_output_dir.Text = Browse_dir_dialog.SelectedPath;
                ms_output_dir_file = Browse_dir_dialog.SelectedPath;
            }

        }

        private void ms_positive_click_Click(object sender, EventArgs e)
        {
            adduct_type = 0;
            ionization_mode_local = 0;
            active_tab = tabControl1.SelectedIndex;
            Select_adducts adds = new Select_adducts();
            adds.Show();
            this.Hide();
        }

        private void ms_negative_click_Click(object sender, EventArgs e)
        {
            adduct_type = 1;
            ionization_mode_local = 1;
            active_tab = tabControl1.SelectedIndex;
            Select_adducts adds = new Select_adducts();
            adds.Show();
            this.Hide();
        }

        private void ms_unknown_click_Click(object sender, EventArgs e)
        {
            adduct_type = 2;
            ionization_mode_local = 2;
            MessageBox.Show("Unknown ionization mode is selected");
            ms_adduct_count.Text = "You have selected unknown ionization mode";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //MS-MS positive adduct
            adduct_type = 0;
            ionization_mode_local = 0;
            active_tab = tabControl1.SelectedIndex;
            Select_adducts adds = new Select_adducts();
            adds.Show();
            this.Hide();
        }

        private void msms_neg_adduct_Click(object sender, EventArgs e)
        {
            adduct_type = 1;
            ionization_mode_local = 1;
            active_tab = tabControl1.SelectedIndex;
            Select_adducts adds = new Select_adducts();
            adds.Show();
            this.Hide();
        }

        private void msms_unknown_adduct_Click(object sender, EventArgs e)
        {
            adduct_type = 2;
            ionization_mode_local = 2;
            MessageBox.Show("Unknown ionization mode is selected");
            ms_adduct_count.Text = "You have selected unknown ionization mode";
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Create_Custom_DB_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd_reference_fasta = new OpenFileDialog();
            Create_Custom_DB_browse_file.Filter = "Text file (*.txt)|*.txt";
            if (Create_Custom_DB_browse_file.ShowDialog() == DialogResult.OK)
            {
                Create_Custom_DB_upload_path.Text = Create_Custom_DB_browse_file.FileName;
            }
        }

        private void Create_Custom_DB_fragment_check_CheckedChanged(object sender, EventArgs e)
        {
            if (Create_Custom_DB_fragment_check.Checked == true)
            {
                Create_Custom_DB_list_of_fragments.Enabled = true;
                Create_Custom_DB_set_spectra_type.Enabled = true;
                Create_Custom_DB_list_of_fragments.Text = "";
            }
            else
            {
                Create_Custom_DB_list_of_fragments.Enabled = false;
                Create_Custom_DB_set_spectra_type.Enabled = false;
            }

        }

        private void Create_Custom_DB_spectra_type_label_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void Create_Custom_DB_list_of_fragments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Create_Custom_DB_list_of_fragments.SelectedItem.ToString() == "Positive")
            {
                Create_Custom_DB_set_spectra_type.Items.Clear();
                Create_Custom_DB_set_spectra_type.Items.Add("EI-MS");
                Create_Custom_DB_set_spectra_type.Items.Add("ESI-MS/MS (CE)");
                Create_Custom_DB_set_spectra_type.Items.Add("ESI-MS/MS (SE)");
            }
            else
            {
                Create_Custom_DB_set_spectra_type.Text = "";
                Create_Custom_DB_set_spectra_type.Items.Clear();
                Create_Custom_DB_set_spectra_type.Items.Add("ESI-MS/MS (SE)");
            }
        }

        public int create_directory(string path)
        {
            int ret = 0;
            if (System.IO.Directory.Exists(path + "\\" + "CFM-ID_Predicted"))
            {
                try
                {
                    System.IO.Directory.Delete(path + "\\" + "CFM-ID_Predicted");
                    System.IO.Directory.CreateDirectory(path + "\\" + "CFM-ID_Predicted");
                    ret = 1;
                }
                catch (Exception ee)
                {
                    MessageBox.Show("(Prediction of MS/MS fragment halted !!!) The directory already exist. Please delete/rename the directory from: " + path + "\\CFM-ID_Predicted", ee.Message);
                    ret= 0;
                }
                
            }
            else
            {
                System.IO.Directory.CreateDirectory(path + "\\" + "CFM-ID_Predicted");
                ret = 1;
            }
            return ret;
        }

        private void Create_Custom_DB_submit_Click(object sender, EventArgs e)
        {
            if (System.IO.File.Exists(Create_Custom_DB_upload_path.Text) && !Create_Custom_DB_upload_path.Text.Contains(" "))
            {
                if (System.IO.Directory.Exists(Create_Custom_DB_set_op_dir.Text) && !Create_Custom_DB_set_op_dir.Text.Contains(" "))
                {
                    if (System.IO.File.Exists(Create_Custom_DB_set_op_dir.Text + "\\" + "parameters.log"))
                    {
                        System.IO.File.Delete(Create_Custom_DB_set_op_dir.Text + "\\" + "parameters.log");
                    }
                    string cfm_id_path = System.IO.Directory.GetCurrentDirectory() + "\\" + "cfm-id-2.4_win32" + "\\";
                    string cfm_id_model = "";
                    int sw = 0;
                    if (Create_Custom_DB_fragment_check.Checked == true)
                    {
                        if (Create_Custom_DB_list_of_fragments.SelectedIndex > -1 && Create_Custom_DB_set_spectra_type.SelectedIndex > -1)
                        {
                            if (Create_Custom_DB_list_of_fragments.SelectedItem.ToString() == "Positive" && Create_Custom_DB_set_spectra_type.SelectedItem.ToString() == "EI-MS")
                            {
                                cfm_id_model = "ei_nn_iso_new";
                            }
                            else if (Create_Custom_DB_list_of_fragments.SelectedItem.ToString() == "Positive" && Create_Custom_DB_set_spectra_type.SelectedItem.ToString() == "ESI-MS/MS (CE)")
                            {
                                cfm_id_model = "params_metab_ce_cfm";
                            }
                            else if (Create_Custom_DB_list_of_fragments.SelectedItem.ToString() == "Positive" && Create_Custom_DB_set_spectra_type.SelectedItem.ToString() == "ESI-MS/MS (SE)")
                            {
                                cfm_id_model = "params_metab_se_cfm";
                            }
                            else if (Create_Custom_DB_list_of_fragments.SelectedItem.ToString() == "Negative" && Create_Custom_DB_set_spectra_type.SelectedItem.ToString() == "ESI-MS/MS (SE)")
                            {
                                cfm_id_model = "negative_se_params";
                            }

                            if (create_directory(Create_Custom_DB_set_op_dir.Text) == 1)
                            {

                                cmd = "/C " + cfm_id_path + "cfm-predict.exe " + Create_Custom_DB_upload_path.Text + " 0.001 " + cfm_id_path + cfm_id_model + "\\" + "param_output0.log " + cfm_id_path + cfm_id_model + "\\" + "param_config.txt " + "0 " + Create_Custom_DB_set_op_dir.Text + "\\" + "CFM-ID_Predicted";
                                ProcessRunner_terminal(cmd);
                                sw = 1;
                                MessageBox.Show("Prediction of fragments: Completed (Press OK)");
                                System.IO.File.AppendAllText(Create_Custom_DB_set_op_dir.Text + "/" + "parameters.log", "Input file: " + Create_Custom_DB_upload_path.Text + Environment.NewLine);
                                System.IO.File.AppendAllText(Create_Custom_DB_set_op_dir.Text + "/" + "parameters.log", "Output file: " + Create_Custom_DB_set_op_dir.Text + Environment.NewLine);
                                System.IO.File.AppendAllText(Create_Custom_DB_set_op_dir.Text + "/" + "parameters.log", "Ionization mode: " + Create_Custom_DB_list_of_fragments.SelectedItem.ToString() + Environment.NewLine);
                                System.IO.File.AppendAllText(Create_Custom_DB_set_op_dir.Text + "/" + "parameters.log", "Spectra type: " + Create_Custom_DB_set_spectra_type.SelectedItem.ToString() + Environment.NewLine);
                            }
                        }
                        else
                        {
                            MessageBox.Show("(Prediction of MS/MS fragment halted !!!) Please select ionization mode and spectra type for prediction of MS/MS fragments");
                        }
                    }
                    if (Create_Custom_DB_calc_monoisotopicmass.Checked == true)
                    {
                        cmd = "/C " + System.IO.Directory.GetCurrentDirectory() + "\\MonoIsotopicMassCalculator\\MonoIsotopicMassCalculator.exe " + Create_Custom_DB_upload_path.Text + " " + Create_Custom_DB_set_op_dir.Text + "\\";
                        ProcessRunner_terminal(cmd);
                        MessageBox.Show("Monoisotopic Mass calculation: Completed (Press OK)");
                        sw = 1;
                    }
                    if(sw ==0 && Create_Custom_DB_fragment_check.Checked == false)
                    {
                        MessageBox.Show("Please select any of the above tasks to execute");
                    }

                }
                else
                {
                    if (Create_Custom_DB_set_op_dir.Text.Contains(" "))
                    {
                        MessageBox.Show("Please avoid spaces in directory path or folder");
                    }
                    else
                    {
                        MessageBox.Show("Invalid path for output directory");
                    }
                }
            }
            else
            {
                if (Create_Custom_DB_upload_path.Text.Contains(" "))
                {
                    MessageBox.Show("Please avoid spaces in input file path or name");
                }
                else
                {
                    MessageBox.Show("Please select input file");
                }
            }
        }

        private void Create_Custom_DB_browse_op_dir_Click(object sender, EventArgs e)
        {
            
            Create_Custom_DB_set_op_dir.Text = "";
            string cfmid_path = "";
            if (Create_Custom_DB_browse_op_path.ShowDialog() == DialogResult.OK)
            {
                Create_Custom_DB_set_op_dir.Text = Create_Custom_DB_browse_op_path.SelectedPath;
                cfmid_path = Create_Custom_DB_browse_op_path.SelectedPath;
            }

        }

        private void ms_search_submit_Click(object sender, EventArgs e)
        {

        }

        private void ms_browse_input_file_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd_reference_fasta = new OpenFileDialog();
            Browse_query_file_dialog.Filter = "Text file (*.txt)|*.txt";
            if (Browse_query_file_dialog.ShowDialog() == DialogResult.OK)
            {
                ms_set_input_file.Text = Browse_query_file_dialog.FileName;
                query_file_ms = Browse_query_file_dialog.FileName;
            }
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void CID_energy_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Parent_da_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Fragment_da_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void ms_reset_Click(object sender, EventArgs e)
        {
            ms_set_input_file.Text = "Load input file";
            browse_species.Text = "Load monoisotopic mass file";
            ms_set_output_dir.Text = "Set output directory";
            //species_call = "0";

            Select_adducts.int_items.Clear();
            Select_species.int_items.Clear();

            Select_species.selected_item.Clear();
            Select_adducts.selected_adduct_items.Clear();
            Select_species.selected_items.Clear();

            ms_ms_species_count.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
            ms_select_species_lbl.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";

            adduct_items_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count + " adducts";
            ms_adduct_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count().ToString() + " adducts";


            ionization_mode = "";
            active_tab = 0;
            query_file = "";
            output_dir_file = "";
            mono_isotopic_mass = "";
            database_file = "";
            query_file_ms = "";
            ms_output_dir_file = "";

        }

        private void msms_reset_Click(object sender, EventArgs e)
        {
            Load_query_file.Text = "Query file here";
            Load_database.Text = "Load database directory";
            Load_monoisotopic_mass.Text = "Load monoisotopic mass";
            Output_dir.Text = "Set output directory";

            Select_adducts.int_items.Clear();
            Select_species.int_items.Clear();

            Select_species.selected_item.Clear();
            Select_adducts.selected_adduct_items.Clear();

            Select_species.database_file_species = "";
            Load_monoisotopic_mass.Enabled = false;
            ms_ms_load_monoisotopic_mass_label.Enabled = false;
            Browse_monoisotopic_mass.Enabled = false;


            ms_ms_species_count.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";
            ms_select_species_lbl.Text = "You have selected " + Select_species.int_items.Count().ToString() + " species";

            adduct_items_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count + " adducts";
            ms_adduct_count.Text = "You have selected " + Select_adducts.selected_adduct_items.Count().ToString() + " adducts";

            Select_species.ms_compound_fldr = "";
            Output_dir.Text = "Output directory here";
            Select_species.query_file_species = "";
            Select_species.output_dir_file_species = "";
            output_dir_file = "";
            Select_species.query_file_species = "";
            query_file_ms = "";
            query_file = "";


            Select_adducts.query_file_species = "";
            Select_adducts.output_dir_file_species = "";

        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void browse_species_TextChanged(object sender, EventArgs e)
        {

        }

        private void Load_query_file_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

